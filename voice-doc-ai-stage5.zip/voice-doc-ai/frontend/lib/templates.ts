export const TEMPLATES: { id: string; name: string; hint: string; title: string; content: string }[] = [
  { id: "blank", name: "Blank document", hint: "Start from nothing", title: "Untitled document", content: "" },
  {
    id: "letter", name: "Formal letter", hint: "Sender, recipient, body", title: "Letter",
    content: "[Your name]\n[Your address]\n[Date]\n\n[Recipient name]\n[Recipient address]\n\nDear [Name],\n\nSubject: [Subject]\n\n[Write your message here.]\n\nYours sincerely,\n[Your name]",
  },
  {
    id: "report", name: "Academic report", hint: "Intro, findings, conclusion", title: "Report",
    content: "TITLE OF REPORT\n\nAbstract\n[Short summary]\n\n1. Introduction\n[Background and purpose]\n\n2. Methodology\n[How the work was done]\n\n3. Findings\n[Results]\n\n4. Conclusion\n[Summary and recommendations]\n\nReferences\n",
  },
  {
    id: "minutes", name: "Meeting minutes", hint: "Attendees, decisions, actions", title: "Meeting minutes",
    content: "MEETING MINUTES\n\nDate: \nTime: \nVenue: \nAttendees: \nApologies: \n\nAgenda\n1. \n2. \n\nDiscussion and decisions\n\nAction items\n- [Person] - [Task] - [Deadline]\n\nNext meeting: \nMinutes taken by: ",
  },
  {
    id: "proposal", name: "Project proposal", hint: "Problem, plan, budget", title: "Proposal",
    content: "PROJECT PROPOSAL\n\nProject title: \nSubmitted by: \nDate: \n\nProblem statement\n\nObjectives\n\nProposed solution\n\nTimeline\n\nBudget\n\nExpected outcomes\n",
  },
  {
    id: "cv", name: "CV", hint: "Profile, experience, skills", title: "Curriculum vitae",
    content: "[FULL NAME]\n[Phone] | [Email] | [Location]\n\nPROFILE\n[Two or three sentences]\n\nEXPERIENCE\n[Role], [Organisation] ([Years])\n- \n\nEDUCATION\n[Qualification], [Institution] ([Year])\n\nSKILLS\n- \n\nREFEREES\nAvailable on request",
  },
];
