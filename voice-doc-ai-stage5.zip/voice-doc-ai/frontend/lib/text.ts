const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

/** Plain text -> HTML paragraphs (blank line = new paragraph, single newline = line break). */
export function plainToHtml(text: string): string {
  if (!text.trim()) return "";
  return text
    .replace(/\r\n/g, "\n")
    .split(/\n{2,}/)
    .map((p) => `<p>${esc(p).replace(/\n/g, "<br>")}</p>`)
    .join("");
}

/** Stored content may be Stage 1 plain text or Stage 2 HTML. Always returns HTML. */
export function toHtml(content: string): string {
  if (!content.trim()) return "";
  return /^\s*<[a-z!]/i.test(content) ? content : plainToHtml(content);
}

export function htmlWordCount(html: string): number {
  const t = html.replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").trim();
  return t ? t.split(/\s+/).length : 0;
}
