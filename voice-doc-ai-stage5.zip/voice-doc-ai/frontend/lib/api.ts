"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export type User = { id: number; name: string; email: string };
export type DocSummary = { id: number; title: string; preview: string; updated: string };
export type Doc = { id: number; title: string; content: string; created: string; updated: string };
export type Version = { id: number; title: string; preview: string; created: string };

export const getToken = () => (typeof window === "undefined" ? null : localStorage.getItem("vd_token"));
export const setToken = (t: string) => localStorage.setItem("vd_token", t);
export const clearToken = () => localStorage.removeItem("vd_token");

export async function api<T = unknown>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  let res: Response;
  try {
    res = await fetch(`${BASE}/api${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init.headers || {}),
      },
    });
  } catch {
    throw new Error("Cannot reach the server. Check that the backend is running and your connection is working.");
  }
  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const d = (data as { detail?: unknown }).detail;
    const msg = typeof d === "string" ? d : Array.isArray(d) ? "Some fields are invalid. Check what you entered." : "Something went wrong.";
    const err = new Error(msg) as Error & { status?: number };
    err.status = res.status;
    throw err;
  }
  return data as T;
}

/** Redirects to /login when there is no valid session. */
export function useAuth() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    if (!getToken()) { router.replace("/login"); return; }
    api<User>("/auth/me").then(setUser).catch(() => { clearToken(); router.replace("/login"); });
  }, [router]);
  return user;
}

export function timeAgo(iso: string) {
  const s = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return new Date(iso).toLocaleDateString();
}

export async function uploadFile<T = unknown>(path: string, file: File): Promise<T> {
  const token = getToken();
  const form = new FormData(); form.append("file", file);
  let res: Response;
  try { res = await fetch(`${BASE}/api${path}`, { method: "POST", headers: token ? { Authorization: `Bearer ${token}` } : {}, body: form }); }
  catch { throw new Error("Cannot reach the server. Check that the backend is running and your connection is working."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "The file could not be processed.");
  return data as T;
}

export async function downloadExport(format: string, title: string, content: string) {
  const token = getToken();
  const res = await fetch(`${BASE}/api/export/${format}`, { method: "POST", headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: JSON.stringify({ title, content }) });
  if (!res.ok) { const data = await res.json().catch(() => ({})); throw new Error(typeof data.detail === "string" ? data.detail : "Export failed."); }
  const blob = await res.blob(); const url = URL.createObjectURL(blob); const a = document.createElement("a");
  a.href = url; a.download = `${title.replace(/[^\w\- ]+/g, "").trim() || "document"}.${format}`; a.click(); URL.revokeObjectURL(url);
}
