import { BASE, getToken } from "./api";
import type { Lang } from "./dictation";

/* eslint-disable @typescript-eslint/no-explicit-any */
const SR = (): any => (typeof window === "undefined" ? null : (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition || null);

export type Listener = { result: Promise<string>; stop: () => void; cancel: () => void };

const SR_ERRORS: Record<string, string> = {
  "not-allowed": "The browser blocked speech recognition. Allow the microphone for this site.",
  "service-not-allowed": "The browser blocked speech recognition. Allow the microphone for this site.",
  network: "Speech recognition needs an internet connection. You can type the command instead.",
  "language-not-supported": "This browser cannot recognise that language by voice. Choose Hausa or Auto (uses Whisper), or type the command.",
};

/** Listens for ONE spoken command. Browser speech where it works, otherwise record + your own Whisper server. */
export function listenOnce(lang: Lang): Listener {
  const ctl = { stop: () => {}, cancel: () => {} };
  const useBrowser = !!SR() && !!lang.speech && lang.id !== "ha";
  const result = useBrowser ? viaBrowser(lang, ctl) : viaWhisper(lang, ctl);
  return { result, stop: () => ctl.stop(), cancel: () => ctl.cancel() };
}

function viaBrowser(lang: Lang, ctl: { stop: () => void; cancel: () => void }): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new (SR())();
    r.lang = lang.speech; r.continuous = false; r.interimResults = false; r.maxAlternatives = 1;
    let text = "", cancelled = false;
    r.onresult = (e: any) => { for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) text += e.results[i][0].transcript + " "; };
    r.onerror = (e: any) => { if (e.error === "no-speech" || e.error === "aborted") return; reject(new Error(SR_ERRORS[e.error] || `Speech recognition failed (${e.error}).`)); };
    r.onend = () => resolve(cancelled ? "" : text.trim());
    ctl.stop = () => { try { r.stop(); } catch {} };
    ctl.cancel = () => { cancelled = true; try { r.abort(); } catch {} };
    try { r.start(); } catch { reject(new Error("The microphone is busy. Try again.")); }
  });
}

function viaWhisper(lang: Lang, ctl: { stop: () => void; cancel: () => void }): Promise<string> {
  return (async () => {
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia)
      throw new Error("Microphone access needs a secure page. Open the app at http://localhost:3000 on this device, or use HTTPS.");
    if (typeof MediaRecorder === "undefined") throw new Error("This browser cannot record audio. You can type the command instead.");
    let early = false, cancelled = false;
    ctl.stop = () => { early = true; };
    ctl.cancel = () => { early = true; cancelled = true; };
    let stream: MediaStream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch (e) {
      const n = (e as DOMException).name;
      throw new Error(n === "NotAllowedError" ? "Microphone blocked. Allow microphone access for this site in your browser settings."
        : n === "NotFoundError" ? "No microphone was found on this device." : "The microphone could not be started.");
    }
    const rec = new MediaRecorder(stream);
    const chunks: Blob[] = [];
    const done = new Promise<Blob>((res) => {
      rec.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
      rec.onstop = () => { stream.getTracks().forEach((t) => t.stop()); res(new Blob(chunks, { type: rec.mimeType || "audio/webm" })); };
    });
    ctl.stop = () => { if (rec.state !== "inactive") rec.stop(); };
    ctl.cancel = () => { cancelled = true; ctl.stop(); };
    rec.start();
    if (early) ctl.stop();
    const limit = setTimeout(() => ctl.stop(), 20000);
    const blob = await done;
    clearTimeout(limit);
    if (cancelled || blob.size === 0) return "";
    const ext = blob.type.includes("mp4") ? "m4a" : blob.type.includes("ogg") ? "ogg" : "webm";
    const fd = new FormData();
    fd.append("audio", blob, `command.${ext}`);
    fd.append("language", lang.whisper);
    let res: Response;
    try { res = await fetch(`${BASE}/api/transcribe`, { method: "POST", headers: { Authorization: `Bearer ${getToken()}` }, body: fd }); }
    catch { throw new Error("Cannot reach the server. Check that the backend is running."); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Transcription failed. Try again.");
    return String(data.text || "").trim();
  })();
}
