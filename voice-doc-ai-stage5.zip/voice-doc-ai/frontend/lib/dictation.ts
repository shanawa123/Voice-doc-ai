export type Lang = { id: string; label: string; speech: string; whisper: string };

export const LANGUAGES: Lang[] = [
  { id: "en", label: "English", speech: "en-US", whisper: "en" },
  { id: "ha", label: "Hausa", speech: "ha-NG", whisper: "ha" },
  { id: "ar", label: "Arabic", speech: "ar-SA", whisper: "ar" },
  { id: "fr", label: "French", speech: "fr-FR", whisper: "fr" },
  { id: "es", label: "Spanish", speech: "es-ES", whisper: "es" },
  { id: "sw", label: "Swahili", speech: "sw-KE", whisper: "sw" },
  { id: "auto", label: "Auto-detect (Whisper only)", speech: "", whisper: "auto" },
];

// A phrase counts only when it is a whole word/phrase (works for Latin and Arabic script).
const w = (phrase: string) => new RegExp(`(?<![\\p{L}\\p{N}])${phrase}(?![\\p{L}\\p{N}])`, "giu");

const SPOKEN: Record<string, [RegExp, string][]> = {
  en: [
    [w("new paragraph"), "\n\n"], [w("(?:new|next) line"), "\n"],
    [w("full stop|period"), ". "], [w("comma"), ", "], [w("question mark"), "? "],
    [w("exclamation (?:mark|point)"), "! "], [w("colon"), ": "], [w("semi-?colon"), "; "],
  ],
  fr: [
    [w("nouveau paragraphe"), "\n\n"], [w("à la ligne|nouvelle ligne"), "\n"],
    [w("point final"), ". "], [w("virgule"), ", "], [w("point d['’ ]interrogation"), "? "],
    [w("point d['’ ]exclamation"), "! "], [w("deux[- ]points"), ": "], [w("point[- ]virgule"), "; "],
  ],
  ar: [
    [w("فقرة جديدة"), "\n\n"], [w("سطر جديد"), "\n"],
    [w("نقطة"), ". "], [w("فاصلة"), "، "], [w("علامة استفهام"), "؟ "], [w("علامة تعجب"), "! "],
  ],
};

/** Turn spoken punctuation ("comma", "new paragraph") into symbols and tidy spacing and capitals. */
export function cleanTranscript(text: string, langId: string): string {
  let t = text;
  for (const [re, out] of SPOKEN[langId] ?? []) t = t.replace(re, out);
  t = t
    .replace(/[ \t]+([.,!?;:،؟])/g, "$1")   // no space before punctuation
    .replace(/[ \t]{2,}/g, " ")
    .replace(/ *\n */g, "\n")
    .trim();
  return t.replace(/(^|[.!?؟]\s+|\n)(\p{Ll})/gu, (_m, a: string, b: string) => a + b.toUpperCase());
}
