import type { Editor } from "@tiptap/react";
import { DOMParser as PMDOMParser, Fragment, MarkType, Node as PMNode } from "@tiptap/pm/model";

/* ---------- what the command engine sees ---------- */
export type DocBlock = { i: number; type: string; level?: number; text: string; items?: string[]; align?: string };
export type Description = {
  blocks: DocBlock[];
  selection: { blocks: number[]; text: string; cursor_block: number | null };
};

const TYPE: Record<string, string> = {
  paragraph: "paragraph", heading: "heading", bulletList: "bullet_list", orderedList: "ordered_list",
  blockquote: "blockquote", table: "table", image: "image", pageBreak: "page_break",
  horizontalRule: "rule", codeBlock: "code",
};

export function describeDocument(editor: Editor): Description {
  const { doc, selection } = editor.state;
  const blocks: DocBlock[] = [];
  const spans: [number, number][] = [];
  doc.forEach((node, offset) => {
    const type = TYPE[node.type.name] ?? node.type.name;
    const b: DocBlock = { i: blocks.length + 1, type, text: "" };
    if (type === "heading") b.level = node.attrs.level;
    if (type === "bullet_list" || type === "ordered_list") {
      const items: string[] = [];
      node.forEach((li) => items.push(li.textContent));
      b.items = items;
    } else if (type === "table") b.text = node.textContent.slice(0, 300);
    else if (type !== "image" && type !== "page_break" && type !== "rule") b.text = node.textContent;
    const al = node.attrs?.textAlign;
    if (al && al !== "left") b.align = al;
    blocks.push(b);
    spans.push([offset, offset + node.nodeSize]);
  });
  const sel: number[] = [];
  let cursor: number | null = null;
  spans.forEach(([s, e], idx) => {
    if (!selection.empty && selection.from < e && selection.to > s) sel.push(idx + 1);
    if (cursor === null && selection.head > s && selection.head < e) cursor = idx + 1;
  });
  if (cursor === null && blocks.length) cursor = blocks.length;
  const text = selection.empty ? "" : doc.textBetween(selection.from, selection.to, " ").slice(0, 5000);
  return { blocks, selection: { blocks: sel, text, cursor_block: cursor } };
}

/* ---------- actions ---------- */
export type NewBlock = { type: string; level?: number; text?: string; items?: string[]; rows?: string[][] };
export type Marks = { bold?: boolean; italic?: boolean; underline?: boolean; strike?: boolean };
export type Action =
  | { type: "set_title"; text: string }
  | { type: "replace_blocks"; from: number; to: number; blocks: NewBlock[] }
  | { type: "format_text"; scope: "selection" | "blocks" | "document"; from?: number; to?: number; marks?: Marks;
      align?: string; font_family?: string; font_size?: string; color?: string; highlight?: string }
  | { type: "find_replace"; find: string; replace: string; match_case?: boolean }
  | { type: "insert_text"; text: string; where: "cursor" | "end" | "start" }
  | { type: "page_break"; after?: number | null };

export type ApplyResult = { changed: boolean; titleChanged: boolean; notes: string[]; error?: string };

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const nl = (s?: string) => esc(s ?? "").replace(/\n/g, "<br>");

function blockHtml(b: NewBlock): string {
  switch (b.type) {
    case "heading": { const l = Math.min(3, Math.max(1, b.level ?? 1)); return `<h${l}>${nl(b.text)}</h${l}>`; }
    case "bullet_list": return b.items?.length ? `<ul>${b.items.map((i) => `<li>${esc(i)}</li>`).join("")}</ul>` : "";
    case "ordered_list": return b.items?.length ? `<ol>${b.items.map((i) => `<li>${esc(i)}</li>`).join("")}</ol>` : "";
    case "blockquote": return `<blockquote><p>${nl(b.text)}</p></blockquote>`;
    case "table":
      return b.rows?.length
        ? `<table><tbody>${b.rows.map((r, ri) => `<tr>${r.map((c) => (ri === 0 ? `<th>${esc(c)}</th>` : `<td>${esc(c)}</td>`)).join("")}</tr>`).join("")}</tbody></table>`
        : "";
    case "page_break": return `<div data-page-break="true"></div>`;
    default: return `<p>${nl(b.text)}</p>`;
  }
}

function toFragment(editor: Editor, blocks: NewBlock[]): Fragment {
  const el = document.createElement("div");
  el.innerHTML = blocks.map(blockHtml).join("");
  return PMDOMParser.fromSchema(editor.schema).parse(el).content;
}

type Span = { pos: number; end: number; node: PMNode };
type Rep = { from: number; to: number; blocks: NewBlock[] };
const conflict = (a: Rep, b: Rep) => {
  const ai = a.to < a.from, bi = b.to < b.from;
  if (ai && bi) return a.from === b.from;
  if (ai) return b.from <= a.from && a.from <= b.to;
  if (bi) return a.from <= b.from && b.from <= a.to;
  return !(a.to < b.from || a.from > b.to);
};
const escRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** Applies every action in ONE transaction, so a single Undo reverts the whole command. */
export function applyActions(editor: Editor, actions: Action[], desc: Description, setTitle: (t: string) => void): ApplyResult {
  const { state } = editor;
  const { schema } = state;
  const spans: Span[] = [];
  state.doc.forEach((node, offset) => spans.push({ pos: offset, end: offset + node.nodeSize, node }));
  const n = spans.length;
  const cursor = desc.selection.cursor_block ?? n;
  const notes: string[] = [];

  const reps: Rep[] = [];
  const formats: Extract<Action, { type: "format_text" }>[] = [];
  const finds: Extract<Action, { type: "find_replace" }>[] = [];
  const inserts: Extract<Action, { type: "insert_text" }>[] = [];
  let newTitle: string | null = null;

  for (const a of actions) {
    if (a.type === "set_title") newTitle = a.text;
    else if (a.type === "replace_blocks") reps.push({ from: a.from, to: a.to, blocks: a.blocks });
    else if (a.type === "page_break") { const after = a.after ?? cursor; reps.push({ from: after + 1, to: after, blocks: [{ type: "page_break" }] }); }
    else if (a.type === "format_text") formats.push(a);
    else if (a.type === "find_replace") finds.push(a);
    else if (a.type === "insert_text") inserts.push(a);
  }
  for (let i = 0; i < reps.length; i++) for (let j = i + 1; j < reps.length; j++)
    if (conflict(reps[i], reps[j])) return { changed: false, titleChanged: false, notes, error: "Those changes overlap, so nothing was changed. Try one change at a time." };
  for (const r of reps) if (r.from < 1 || r.from > n + 1 || r.to > n) return { changed: false, titleChanged: false, notes, error: "The document no longer matches the command. Run it again." };

  let tr = state.tr;

  // 1. styling (positions are original; none of this changes sizes)
  const markTypes: Record<string, MarkType | undefined> = {
    bold: schema.marks.bold, italic: schema.marks.italic, underline: schema.marks.underline, strike: schema.marks.strike,
  };
  for (const f of formats) {
    let from: number, to: number;
    if (f.scope === "selection") {
      if (state.selection.empty) { notes.push("Select some text first."); continue; }
      from = state.selection.from; to = state.selection.to;
    } else if (f.scope === "blocks") {
      const a = spans[(f.from ?? 0) - 1], b = spans[(f.to ?? f.from ?? 0) - 1];
      if (!a || !b) continue;
      from = a.pos + 1; to = b.end - 1;
    } else { from = 0; to = state.doc.content.size; }
    if (to <= from) continue;

    for (const [k, on] of Object.entries(f.marks ?? {})) {
      const mt = markTypes[k];
      if (!mt) continue;
      if (on) tr.addMark(from, to, mt.create()); else tr.removeMark(from, to, mt);
    }
    const ts: Record<string, string> = {};
    if (f.font_family) ts.fontFamily = f.font_family;
    if (f.font_size) ts.fontSize = f.font_size;
    if (f.color) ts.color = f.color;
    const textStyle = schema.marks.textStyle;
    if (Object.keys(ts).length && textStyle) {
      state.doc.nodesBetween(from, to, (node, pos) => {
        if (!node.isText) return;
        const old = node.marks.find((m) => m.type === textStyle);
        tr.addMark(Math.max(from, pos), Math.min(to, pos + node.nodeSize), textStyle.create({ ...(old?.attrs ?? {}), ...ts }));
      });
    }
    if (f.highlight && schema.marks.highlight) tr.addMark(from, to, schema.marks.highlight.create({ color: f.highlight }));
    if (f.align) {
      for (const s of spans) {
        if (s.end <= from || s.pos >= to) continue;
        if (!("textAlign" in s.node.type.attrs)) continue;
        tr.setNodeMarkup(s.pos, undefined, { ...s.node.attrs, textAlign: f.align });
      }
    }
  }

  // 2. block replacements, from the end of the document backwards so earlier positions stay valid
  const bounds = (r: Rep) => {
    const from = r.from <= n ? spans[r.from - 1].pos : state.doc.content.size;
    const to = r.to >= r.from ? spans[r.to - 1].end : from;
    return { from, to };
  };
  const ordered = [...reps].sort((a, b) => { const x = bounds(a), y = bounds(b); return y.from - x.from || y.to - x.to; });
  for (const r of ordered) {
    const { from, to } = bounds(r);
    const frag = r.blocks.length ? toFragment(editor, r.blocks) : Fragment.empty;
    if (frag.size > 0) tr = tr.replaceWith(from, to, frag);
    else if (to > from) tr = tr.delete(from, to);
  }

  // 3. find and replace across the (already edited) document
  let replaced = 0;
  for (const fr of finds) {
    const re = new RegExp(escRe(fr.find), fr.match_case ? "g" : "gi");
    const hits: [number, number][] = [];
    tr.doc.descendants((node, pos) => {
      if (!node.isText || !node.text) return;
      re.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = re.exec(node.text)) !== null) {
        if (m[0] === "") break;
        hits.push([pos + m.index, pos + m.index + m[0].length]);
      }
    });
    for (const [s, e] of hits.reverse()) tr.insertText(fr.replace, s, e);
    replaced += hits.length;
    if (!hits.length) notes.push(`"${fr.find}" was not found.`);
  }

  // 4. inserted text
  for (const ins of inserts) {
    if (!ins.text) continue;
    if (ins.where === "cursor") tr.insertText(ins.text);
    else {
      const para = schema.nodes.paragraph.create(null, schema.text(ins.text));
      tr.insert(ins.where === "end" ? tr.doc.content.size : 0, para);
    }
  }

  const changed = tr.docChanged;
  if (changed) editor.view.dispatch(tr);
  if (newTitle) setTitle(newTitle);
  if (replaced) notes.push(`Replaced ${replaced} ${replaced === 1 ? "match" : "matches"}.`);
  return { changed, titleChanged: !!newTitle, notes };
}
