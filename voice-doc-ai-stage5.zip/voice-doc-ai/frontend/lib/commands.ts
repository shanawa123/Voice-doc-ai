import type { Action, Description, Marks } from "./docEdit";

/** Commands that need no AI and send nothing anywhere. English only; everything else goes to the AI engine. */
export type LocalResult = { actions: Action[]; reply: string } | { special: "undo" | "redo" } | null;

const ORD: Record<string, number> = {
  first: 1, second: 2, third: 3, fourth: 4, fifth: 5, sixth: 6, seventh: 7, eighth: 8, ninth: 9, tenth: 10,
  "1st": 1, "2nd": 2, "3rd": 3, "4th": 4, "5th": 5, "6th": 6, "7th": 7, "8th": 8, "9th": 9, "10th": 10,
};
const MARK: Record<string, keyof Marks> = {
  bold: "bold", italic: "italic", italicize: "italic", italicise: "italic", underline: "underline", underlined: "underline",
  strikethrough: "strike", "strike through": "strike", "struck through": "strike",
};
const REF = "(?:this|that|it|the selection|the selected text|selected text|the paragraph|this paragraph)";

export function parseLocal(raw: string, desc: Description, today = new Date(), langId = "en"): LocalResult {
  let o = raw.trim().replace(/[\u2019\u2018]/g, "'").replace(/[.!?]+$/, "").replace(/\s+/g, " ");
  o = o.replace(/^(?:please |can you |could you |would you )+/i, "").replace(/ please$/i, "");
  const t = o.toLowerCase();
  const { selection, blocks } = desc;
  const target = (): Action | null => {
    if (selection.blocks.length && selection.text) return { type: "format_text", scope: "selection" };
    return selection.cursor_block ? { type: "format_text", scope: "blocks", from: selection.cursor_block, to: selection.cursor_block } : null;
  };
  const needTarget = (): LocalResult => ({ actions: [], reply: langId === "ha" ? "Da fatan sanya alamar rubutu a sakin layi ko zaɓi rubutun tukuna." : langId === "ar" ? "ضع المؤشر داخل فقرة أو حدّد النص أولاً." : "Place the cursor in a paragraph or select some text first." });

  // Common offline commands in Hausa and Arabic. These run locally and do not send document text to an AI service.
  const localTarget = target();
  if (langId === "ha") {
    if (/^(?:sake|mayar da baya|sake aikin baya)$/.test(t)) return { special: "undo" };
    if (/^(?:maido|mayar da gaba)$/.test(t)) return { special: "redo" };
    if (/^(?:ka|ki|don Allah )?(?:sanya|mai da) (?:wannan )?(?:rubutu|shi) (?:ya )?(?:yi )?kauri$/.test(t) || /^(?:yi|sanya) (?:wannan )?rubutu bold$/.test(t)) {
      if (!localTarget) return needTarget();
      return { actions: [{ ...localTarget, marks: { bold: true } }], reply: "An sanya rubutun ya yi kauri." };
    }
    if (/^(?:sanya|mai da) (?:wannan )?rubutu karkata$/.test(t)) {
      if (!localTarget) return needTarget();
      return { actions: [{ ...localTarget, marks: { italic: true } }], reply: "An karkatar da rubutun." };
    }
    if (/^(?:ja|sanya) layi a ƙarƙashin (?:wannan )?rubutu$/.test(t)) {
      if (!localTarget) return needTarget();
      return { actions: [{ ...localTarget, marks: { underline: true } }], reply: "An ja layi a ƙarƙashin rubutun." };
    }
    if (/^(?:ƙara|saka|buɗe) sabon shafi$/.test(t)) return { actions: [{ type: "page_break", after: null }], reply: "An ƙara sabon shafi." };
    if (/^(?:saka|ƙara) (?:ranar yau|kwanan wata)$/.test(t)) {
      const d = today.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
      return { actions: [{ type: "insert_text", text: d, where: "cursor" }], reply: `An saka ${d}.` };
    }
  }
  if (langId === "ar") {
    if (/^(?:تراجع|إلغاء آخر تعديل)$/.test(t)) return { special: "undo" };
    if (/^(?:إعادة|أعد التعديل)$/.test(t)) return { special: "redo" };
    if (/^(?:اجعل|حوّل) (?:هذا|النص المحدد|التحديد) (?:غامقًا|عريضًا)$/.test(t) || /^(?:غامق|خط عريض)$/.test(t)) {
      if (!localTarget) return needTarget();
      return { actions: [{ ...localTarget, marks: { bold: true } }], reply: "تم جعل النص عريضًا." };
    }
    if (/^(?:اجعل|حوّل) (?:هذا|النص المحدد|التحديد) مائلًا$/.test(t) || /^خط مائل$/.test(t)) {
      if (!localTarget) return needTarget();
      return { actions: [{ ...localTarget, marks: { italic: true } }], reply: "تم جعل النص مائلاً." };
    }
    if (/^(?:ضع خطًا تحت|سطّر) (?:هذا النص|النص المحدد)$/.test(t)) {
      if (!localTarget) return needTarget();
      return { actions: [{ ...localTarget, marks: { underline: true } }], reply: "تم وضع خط تحت النص." };
    }
    if (/^(?:أضف|أنشئ) صفحة جديدة$/.test(t)) return { actions: [{ type: "page_break", after: null }], reply: "تمت إضافة صفحة جديدة." };
    if (/^(?:أدرج|أضف) تاريخ اليوم$/.test(t)) {
      const d = today.toLocaleDateString("ar", { day: "numeric", month: "long", year: "numeric" });
      return { actions: [{ type: "insert_text", text: d, where: "cursor" }], reply: `تم إدراج ${d}.` };
    }
  }

  if (/^(?:undo|undo that|undo last|go back)$/.test(t)) return { special: "undo" };
  if (/^(?:redo|redo that)$/.test(t)) return { special: "redo" };

  let m = o.match(/^(?:change|rename|set|update) (?:the )?(?:document )?title (?:to|as) (.+)$/i);
  if (m) {
    const title = m[1].trim().replace(/^["“'‘]|["”'’]$/g, "");
    return { actions: [{ type: "set_title", text: title.charAt(0).toUpperCase() + title.slice(1) }], reply: `Title changed to "${title}".` };
  }

  m = t.match(new RegExp(`^(?:make|set) ${REF} (bold|italic|underlined?|strikethrough|strike through|struck through)$`))
    || t.match(new RegExp(`^(bold|italicize|italicise|underline|strikethrough|strike through)(?: ${REF})?$`));
  if (m) {
    const tg = target();
    if (!tg || tg.type !== "format_text") return needTarget();
    return { actions: [{ ...tg, marks: { [MARK[m[1]]]: true } }], reply: `Applied ${MARK[m[1]]}.` };
  }
  m = t.match(/^(?:remove|clear|unset|turn off) (bold|italic|underline|strikethrough)(?: formatting)?(?: from (?:this|that|it|the selection))?$/)
    || t.match(/^(?:un)(bold|italicize|underline)(?: .*)?$/) || t.match(/^(?:make|set) (?:this|that|it) not (bold|italic|underlined?)$/);
  if (m) {
    const tg = target();
    if (!tg || tg.type !== "format_text") return needTarget();
    return { actions: [{ ...tg, marks: { [MARK[m[1]]]: false } }], reply: `Removed ${m[1]}.` };
  }

  m = t.match(new RegExp(`^(?:(?:align|make|set) (?:${REF} )?(?:to )?(?:the )?)(left|right|center|centre|justif(?:y|ied))(?: align(?:ed|ment)?)?$`))
    || t.match(new RegExp(`^(center|centre|justify)(?: ${REF})?$`))
    || t.match(new RegExp(`^(left|right) align(?:ed)?(?: ${REF})?$`))
    || t.match(new RegExp(`^(?:make|set) ${REF} (left|right|center|centre|justified)(?: aligned)?$`));
  if (m) {
    const w = m[1];
    const align = w.startsWith("justif") ? "justify" : w === "centre" ? "center" : w;
    const cb = selection.cursor_block;
    if (!cb) return needTarget();
    const from = selection.blocks[0] ?? cb, to = selection.blocks[selection.blocks.length - 1] ?? cb;
    return { actions: [{ type: "format_text", scope: "blocks", from, to, align }], reply: `Aligned ${align === "justify" ? "justified" : align}.` };
  }

  if (/^(?:insert|add|put|type|write)(?: in)? (?:today'?s date|the date|the current date|today'?s date here)$/.test(t)) {
    const d = today.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
    return { actions: [{ type: "insert_text", text: d, where: "cursor" }], reply: `Inserted ${d}.` };
  }

  if (/^(?:(?:add|insert|start|make|create)(?: a)?(?: new)? page(?: break)?|new page|page break)$/.test(t)) {
    return { actions: [{ type: "page_break", after: null }], reply: "Added a page break." };
  }

  m = t.match(/^(?:delete|remove) (?:the )?(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|last|\d+(?:st|nd|rd|th)) paragraph$/);
  if (m) {
    const paras = blocks.filter((b) => b.type === "paragraph" && b.text.trim());
    const k = m[1] === "last" ? paras.length : ORD[m[1]] ?? parseInt(m[1], 10);
    const target = paras[k - 1];
    if (!target) return { actions: [], reply: `I could only find ${paras.length} paragraph${paras.length === 1 ? "" : "s"}.` };
    return { actions: [{ type: "replace_blocks", from: target.i, to: target.i, blocks: [] }], reply: `Deleted the ${m[1]} paragraph.` };
  }
  if (/^(?:delete|remove) (?:this|the current) paragraph$/.test(t)) {
    const cb = selection.cursor_block;
    if (!cb) return needTarget();
    return { actions: [{ type: "replace_blocks", from: cb, to: cb, blocks: [] }], reply: "Deleted this paragraph." };
  }
  return null;
}
