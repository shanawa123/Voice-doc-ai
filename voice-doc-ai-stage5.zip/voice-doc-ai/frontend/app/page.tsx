"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, clearToken, Doc, DocSummary, timeAgo, useAuth, uploadFile } from "@/lib/api";
import { TEMPLATES } from "@/lib/templates";
import { plainToHtml } from "@/lib/text";

const COMING: { label: string; stage: string; note: string }[] = [
  { label: "Upload document", stage: "Stage 5", note: "Open Word, PDF, Excel, PowerPoint" },
  { label: "Scan paper", stage: "Stage 7", note: "Photograph a page and extract the text" },
  { label: "AI assistant", stage: "Stage 6", note: "Write, summarise, translate" },
];

export default function Dashboard() {
  const router = useRouter();
  const user = useAuth();
  const [docs, setDocs] = useState<DocSummary[] | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [importing, setImporting] = useState(false);

  const load = useCallback(() => {
    api<DocSummary[]>("/documents").then(setDocs).catch((e) => setError(e.message));
  }, []);
  useEffect(() => { if (user) load(); }, [user, load]);

  async function create(templateId: string, voice = false) {
    const t = TEMPLATES.find((x) => x.id === templateId)!;
    setBusy(true); setError("");
    try {
      const doc = await api<Doc>("/documents", { method: "POST", body: JSON.stringify({ title: t.title, content: plainToHtml(t.content) }) });
      router.push(`/doc/${doc.id}${voice ? "?voice=1" : ""}`);
    } catch (e) { setError((e as Error).message); setBusy(false); }
  }

  async function importDocument(file?: File) {
    if (!file) return;
    setImporting(true); setError("");
    try {
      const imported = await uploadFile<{ title: string; content: string; source_format: string }>("/import", file);
      const doc = await api<Doc>("/documents", { method: "POST", body: JSON.stringify({ title: imported.title, content: imported.content }) });
      router.push(`/doc/${doc.id}`);
    } catch (e) { setError((e as Error).message); setImporting(false); }
  }

  async function scanImage(file?: File) {
    if (!file) return;
    setImporting(true); setError("");
    try {
      const result = await uploadFile<{ text: string }>("/ocr", file);
      if (!result.text.trim()) throw new Error("No readable text was found. Try a clearer, well-lit image.");
      const doc = await api<Doc>("/documents", { method: "POST", body: JSON.stringify({ title: file.name.replace(/\.[^.]+$/, "") || "Scanned document", content: plainToHtml(result.text) }) });
      router.push(`/doc/${doc.id}`);
    } catch (e) { setError((e as Error).message); setImporting(false); }
  }

  async function remove(d: DocSummary) {
    if (!confirm(`Delete "${d.title}" and its version history? This cannot be undone.`)) return;
    try { await api(`/documents/${d.id}`, { method: "DELETE" }); load(); }
    catch (e) { setError((e as Error).message); }
  }

  if (!user) return <main className="p-8 text-slate">Loading…</main>;

  return (
    <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
      <header className="flex items-center justify-between">
        <h1 className="font-serif text-3xl font-medium">Voice Doc AI</h1>
        <div className="flex items-center gap-3 text-sm">
          <span className="hidden text-slate sm:inline">{user.name}</span>
          <button className="btn-ghost" onClick={() => { clearToken(); router.replace("/login"); }}>Sign out</button>
        </div>
      </header>

      {error && <p role="alert" className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

      <section className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <button className="btn-primary h-full min-h-[84px] flex-col !items-start !justify-between rounded-2xl p-4 text-left lg:col-span-1" disabled={busy} onClick={() => create("blank")}>
          <span className="text-base font-semibold">New document</span>
          <span className="text-xs font-normal opacity-80">{busy ? "Creating…" : "Blank page"}</span>
        </button>
        <button className="btn-ghost h-full min-h-[84px] flex-col !items-start !justify-between rounded-2xl p-4 text-left" disabled={busy} onClick={() => create("blank", true)}>
          <span className="text-base font-semibold">Record voice</span>
          <span className="text-xs font-normal text-slate">Dictate a new document</span>
        </button>
        <label className="btn-ghost flex min-h-[84px] cursor-pointer flex-col !items-start !justify-between rounded-2xl p-4 text-left">
          <span className="text-base font-semibold">{importing ? "Importing…" : "Import document"}</span>
          <span className="text-xs font-normal text-slate">DOCX, PDF, XLSX, PPTX, TXT, MD</span>
          <input type="file" className="sr-only" accept=".docx,.pdf,.xlsx,.pptx,.txt,.md" disabled={importing} onChange={(e) => { void importDocument(e.target.files?.[0]); e.currentTarget.value = ""; }} />
        </label>
        <label className="btn-ghost flex min-h-[84px] cursor-pointer flex-col !items-start !justify-between rounded-2xl p-4 text-left">
          <span className="text-base font-semibold">Scan image (OCR)</span>
          <span className="text-xs font-normal text-slate">Extract text from JPG or PNG</span>
          <input type="file" className="sr-only" accept="image/png,image/jpeg,image/webp" disabled={importing} onChange={(e) => { void scanImage(e.target.files?.[0]); e.currentTarget.value = ""; }} />
        </label>
        {COMING.filter((c) => c.stage !== "Stage 5").map((c) => (
          <div key={c.label} className="flex min-h-[84px] flex-col justify-between rounded-2xl border border-dashed border-line bg-white/60 p-4" aria-disabled="true">
            <div className="flex items-start justify-between gap-2">
              <span className="text-sm font-semibold text-slate">{c.label}</span>
              <span className="rounded-full bg-amber-soft px-2 py-0.5 text-[11px] font-medium text-amber">{c.stage}</span>
            </div>
            <span className="text-xs text-slate">{c.note}</span>
          </div>
        ))}
      </section>

      <section className="mt-10">
        <h2 className="text-lg font-semibold">Start from a template</h2>
        <div className="mt-3 flex gap-3 overflow-x-auto pb-2">
          {TEMPLATES.filter((t) => t.id !== "blank").map((t) => (
            <button key={t.id} disabled={busy} onClick={() => create(t.id)} className="w-44 shrink-0 rounded-xl border border-line bg-white p-4 text-left hover:border-teal disabled:opacity-50">
              <div className="font-serif text-lg">{t.name}</div>
              <div className="mt-1 text-xs text-slate">{t.hint}</div>
            </button>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="text-lg font-semibold">Recent documents</h2>
        {docs === null ? (
          <p className="mt-3 text-sm text-slate">Loading your documents…</p>
        ) : docs.length === 0 ? (
          <p className="mt-3 rounded-xl border border-line bg-white p-6 text-sm text-slate">No documents yet. Choose New document or a template above to begin.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line overflow-hidden rounded-xl border border-line bg-white">
            {docs.map((d) => (
              <li key={d.id} className="flex items-center gap-3 p-4">
                <button className="min-w-0 flex-1 text-left" onClick={() => router.push(`/doc/${d.id}`)}>
                  <div className="truncate font-medium">{d.title}</div>
                  <div className="truncate text-sm text-slate">{d.preview.replace(/\s+/g, " ") || "Empty document"}</div>
                </button>
                <span className="shrink-0 text-xs text-slate">{timeAgo(d.updated)}</span>
                <button className="btn-danger !px-3 !py-1.5" onClick={() => remove(d)} aria-label={`Delete ${d.title}`}>Delete</button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
