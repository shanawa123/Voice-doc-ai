"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, BASE, getToken } from "@/lib/api";
import { cleanTranscript, LANGUAGES } from "@/lib/dictation";

type Phase = "idle" | "recording" | "paused" | "stopped";
type Engine = "live" | "whisper";

/* eslint-disable @typescript-eslint/no-explicit-any */
const speechClass = (): any =>
  typeof window === "undefined" ? null : (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition || null;

function pickMime() {
  if (typeof MediaRecorder === "undefined") return "";
  return ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus"].find((t) => MediaRecorder.isTypeSupported(t)) || "";
}
const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

export default function VoicePanel({ onInsert, onClose }: { onInsert: (text: string) => void; onClose: () => void }) {
  const [langId, setLangId] = useState("en");
  const [engine, setEngine] = useState<Engine>("whisper");
  const [liveOk, setLiveOk] = useState(false);
  const [whisper, setWhisper] = useState<{ available: boolean; model: string } | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const [elapsed, setElapsed] = useState(0);
  const [transcript, setTranscript] = useState("");
  const [interim, setInterim] = useState("");
  const [audioUrl, setAudioUrl] = useState("");
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [tidy, setTidy] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  const recRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunks = useRef<Blob[]>([]);
  const srRef = useRef<any>(null);
  const wantLive = useRef(false);
  const lang = LANGUAGES.find((l) => l.id === langId)!;

  useEffect(() => {
    const ok = !!speechClass();
    setLiveOk(ok);
    setEngine(ok ? "live" : "whisper");
    api<{ available: boolean; model: string }>("/transcribe/status").then(setWhisper).catch(() => setWhisper({ available: false, model: "" }));
  }, []);

  useEffect(() => {
    if (phase !== "recording") return;
    const t = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(t);
  }, [phase]);

  const releaseAudio = useCallback(() => {
    wantLive.current = false;
    try { srRef.current?.stop(); } catch {}
    if (recRef.current && recRef.current.state !== "inactive") { try { recRef.current.stop(); } catch {} }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);
  useEffect(() => () => releaseAudio(), [releaseAudio]);
  useEffect(() => () => { if (audioUrl) URL.revokeObjectURL(audioUrl); }, [audioUrl]);

  function startRecognition() {
    const SR = speechClass();
    if (!SR) { setError("Live text is not supported in this browser. Use Whisper, or open the app in Chrome."); return; }
    if (!lang.speech) { setError("Choose a language for live text, or switch to Whisper for auto-detect."); return; }
    const r = new SR();
    r.lang = lang.speech; r.continuous = true; r.interimResults = true;
    r.onresult = (ev: any) => {
      let finals = "", partial = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const res = ev.results[i];
        if (res.isFinal) finals += res[0].transcript + " "; else partial += res[0].transcript;
      }
      if (finals.trim()) setTranscript((t) => (t ? t + " " : "") + finals.trim());
      setInterim(partial);
    };
    r.onerror = (ev: any) => {
      if (ev.error === "no-speech" || ev.error === "aborted") return;
      wantLive.current = false;
      const msg: Record<string, string> = {
        "not-allowed": "The browser blocked speech recognition. Allow the microphone for this site.",
        "service-not-allowed": "The browser blocked speech recognition. Allow the microphone for this site.",
        "network": "Live text needs an internet connection. Keep recording and use Whisper afterwards.",
        "language-not-supported": `This browser cannot recognise ${lang.label} live. Keep recording and use Whisper afterwards.`,
      };
      setError(msg[ev.error] || `Live text stopped (${ev.error}). Your recording continues; use Whisper afterwards.`);
    };
    r.onend = () => {
      setInterim("");
      if (wantLive.current) setTimeout(() => { if (wantLive.current) { try { r.start(); } catch {} } }, 250);
    };
    wantLive.current = true;
    srRef.current = r;
    try { r.start(); } catch {}
  }

  async function start() {
    setError(""); setInfo("");
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      setError("Microphone access needs a secure page. Open the app at http://localhost:3000 on this device, or serve it over HTTPS.");
      return;
    }
    if (typeof MediaRecorder === "undefined") { setError("This browser cannot record audio. Try Chrome, Edge, Firefox or Safari 14.1+."); return; }
    let stream: MediaStream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch (e) {
      const n = (e as DOMException).name;
      setError(n === "NotAllowedError" ? "Microphone blocked. Allow microphone access for this site in your browser settings, then try again."
        : n === "NotFoundError" ? "No microphone was found on this device." : "The microphone could not be started. Close other apps that use it and try again.");
      return;
    }
    streamRef.current = stream; chunks.current = [];
    setAudioBlob(null); setAudioUrl("");
    const mime = pickMime();
    const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    rec.ondataavailable = (e) => { if (e.data.size > 0) chunks.current.push(e.data); };
    rec.onstop = () => {
      const blob = new Blob(chunks.current, { type: rec.mimeType || mime || "audio/webm" });
      if (blob.size > 0) { setAudioBlob(blob); setAudioUrl(URL.createObjectURL(blob)); }
    };
    rec.start(1000);
    recRef.current = rec;
    setElapsed(0); setPhase("recording");
    if (engine === "live") startRecognition();
  }

  function pause() {
    recRef.current?.pause();
    wantLive.current = false; try { srRef.current?.stop(); } catch {}
    setInterim(""); setPhase("paused");
  }
  function resume() {
    recRef.current?.resume(); setPhase("recording");
    if (engine === "live") startRecognition();
  }
  function stop() { releaseAudio(); setInterim(""); setPhase("stopped"); }

  async function transcribeWhisper() {
    if (!audioBlob) return;
    setBusy(true); setError(""); setInfo("");
    const ext = audioBlob.type.includes("mp4") ? "m4a" : audioBlob.type.includes("ogg") ? "ogg" : "webm";
    const fd = new FormData();
    fd.append("audio", audioBlob, `recording.${ext}`);
    fd.append("language", lang.whisper);
    try {
      const res = await fetch(`${BASE}/api/transcribe`, { method: "POST", headers: { Authorization: `Bearer ${getToken()}` }, body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Transcription failed. Try again.");
      if (!data.text) setInfo("No speech was detected in this recording.");
      else setTranscript((t) => (t ? t + "\n\n" : "") + data.text);
    } catch (e) {
      setError(e instanceof TypeError ? "Cannot reach the server. Check that the backend is running." : (e as Error).message);
    } finally { setBusy(false); }
  }

  function insert() {
    const text = tidy ? cleanTranscript(transcript, langId) : transcript.trim();
    if (!text) return;
    onInsert(text);
    setTranscript(""); setInfo("Inserted at the cursor.");
  }
  function discard() {
    releaseAudio(); setPhase("idle"); setTranscript(""); setInterim(""); setAudioBlob(null); setAudioUrl(""); setElapsed(0); setError(""); setInfo("");
  }

  const recording = phase === "recording", paused = phase === "paused", active = recording || paused;
  const rtl = langId === "ar";

  return (
    <section className="mb-4 rounded-xl border border-line bg-white p-4" aria-label="Voice dictation">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-semibold">Dictation</h2>
        <button className="text-sm text-slate underline" onClick={() => { releaseAudio(); onClose(); }}>Close</button>
      </div>

      <div className="mt-3 flex flex-wrap items-end gap-3">
        <label className="text-sm">Language
          <select className="field mt-1 !w-auto" value={langId} disabled={active} onChange={(e) => setLangId(e.target.value)}>
            {LANGUAGES.map((l) => <option key={l.id} value={l.id}>{l.label}</option>)}
          </select>
        </label>
        <fieldset className="text-sm" disabled={active}>
          <legend>Speech engine</legend>
          <div className="mt-1 inline-flex overflow-hidden rounded-lg border border-line">
            <button type="button" disabled={!liveOk} onClick={() => setEngine("live")} aria-pressed={engine === "live"}
              className={`px-3 py-2 ${engine === "live" ? "bg-teal text-white" : "bg-white"} disabled:opacity-40`}>Live text</button>
            <button type="button" onClick={() => setEngine("whisper")} aria-pressed={engine === "whisper"}
              className={`px-3 py-2 ${engine === "whisper" ? "bg-teal text-white" : "bg-white"}`}>Whisper</button>
          </div>
        </fieldset>
      </div>
      <p className="mt-2 text-xs text-slate">
        {engine === "live"
          ? "Live text shows words as you speak, using your browser's speech service (Chrome sends the audio to Google). Hausa is often unsupported there: use Whisper."
          : whisper && !whisper.available
            ? "Whisper is not installed on the server yet, so recordings cannot be transcribed. See the README (requirements-whisper.txt)."
            : "Whisper records first, then converts the recording on your own server when you press Transcribe. Best for Hausa and long notes."}
      </p>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        {!active && <button className="btn-primary" onClick={start}>{phase === "stopped" ? "Record again" : "Record"}</button>}
        {recording && <button className="btn-ghost" onClick={pause}>Pause</button>}
        {paused && <button className="btn-primary" onClick={resume}>Resume</button>}
        {active && <button className="btn-danger" onClick={stop}>Stop</button>}
        {active && (
          <span className="flex items-center gap-2 text-sm" aria-live="polite">
            <span className={`inline-block h-3 w-3 rounded-full ${recording ? "bg-red-600 motion-safe:animate-pulse" : "bg-amber"}`} aria-hidden="true" />
            {recording ? "Recording" : "Paused"} {fmt(elapsed)}
          </span>
        )}
      </div>

      {error && <p role="alert" className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
      {info && <p className="mt-3 rounded-lg bg-teal-soft px-3 py-2 text-sm text-teal-dark" aria-live="polite">{info}</p>}

      {audioUrl && (
        <div className="mt-4">
          <audio controls src={audioUrl} className="w-full" aria-label="Replay recording" />
          {engine === "whisper" || !transcript ? (
            <button className="btn-ghost mt-2" onClick={transcribeWhisper} disabled={busy || (whisper !== null && !whisper.available)}>
              {busy ? "Transcribing… this can take a minute" : "Transcribe with Whisper"}
            </button>
          ) : null}
          {engine === "live" && transcript === "" && phase === "stopped" && (
            <p className="mt-1 text-xs text-slate">No live text was captured. Press Transcribe to convert the recording on your server (this uploads the audio to it).</p>
          )}
        </div>
      )}

      {(phase !== "idle" || transcript) && (
        <div className="mt-4">
          <label className="text-sm font-medium" htmlFor="dictation-text">Transcript (you can edit it before inserting)</label>
          <textarea id="dictation-text" dir={rtl ? "rtl" : "auto"} className="field mt-1 min-h-[8rem] font-serif text-base"
            value={transcript} onChange={(e) => setTranscript(e.target.value)} placeholder="Your words appear here." />
          {interim && <p dir="auto" className="mt-1 text-sm italic text-slate" aria-live="polite">{interim}</p>}
          <label className="mt-2 flex items-center gap-2 text-sm">
            <input type="checkbox" checked={tidy} onChange={(e) => setTidy(e.target.checked)} />
            Tidy punctuation and capitals (turns “comma”, “full stop”, “new paragraph” into symbols)
          </label>
          <div className="mt-3 flex flex-wrap gap-2">
            <button className="btn-primary" onClick={insert} disabled={!transcript.trim()}>Insert into document</button>
            <button className="btn-ghost" onClick={discard}>Discard recording</button>
          </div>
        </div>
      )}
    </section>
  );
}
