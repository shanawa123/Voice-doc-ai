"use client";
import { useEffect, useRef } from "react";
import { Editor, EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import TextAlign from "@tiptap/extension-text-align";
import TextStyle from "@tiptap/extension-text-style";
import FontFamily from "@tiptap/extension-font-family";
import Color from "@tiptap/extension-color";
import Highlight from "@tiptap/extension-highlight";
import Table from "@tiptap/extension-table";
import TableRow from "@tiptap/extension-table-row";
import TableHeader from "@tiptap/extension-table-header";
import TableCell from "@tiptap/extension-table-cell";
import Image from "@tiptap/extension-image";
import Link from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";
import { FontSize } from "@/lib/fontSize";
import { PageBreak } from "@/lib/pageBreak";

const FONTS = ["Newsreader", "Arial", "Georgia", "Times New Roman", "Verdana", "Courier New"];
const SIZES = ["10px", "12px", "14px", "16px", "18px", "20px", "24px", "28px", "36px", "48px"];
const MAX_IMAGE_BYTES = 1_500_000;

type Props = {
  initialHtml: string;
  onChange: (html: string) => void;
  onEditor: (editor: Editor) => void;
  onNotice: (message: string) => void;
};

function Btn(p: { label: string; on: () => void; active?: boolean; disabled?: boolean; children: React.ReactNode }) {
  return (
    <button
      type="button" title={p.label} aria-label={p.label} aria-pressed={p.active} disabled={p.disabled}
      onMouseDown={(e) => e.preventDefault()} onClick={p.on}
      className={`h-9 min-w-9 shrink-0 rounded-md px-2 text-sm font-medium disabled:opacity-40 ${p.active ? "bg-teal text-white" : "hover:bg-teal-soft"}`}
    >{p.children}</button>
  );
}
const Sep = () => <span className="mx-1 h-6 w-px shrink-0 bg-line" aria-hidden="true" />;

export default function RichEditor({ initialHtml, onChange, onEditor, onNotice }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const editor = useEditor({
    immediatelyRender: false,
    content: initialHtml,
    extensions: [
      StarterKit,
      Underline, TextStyle, FontFamily, FontSize, Color, PageBreak,
      Highlight.configure({ multicolor: true }),
      TextAlign.configure({ types: ["heading", "paragraph"] }),
      Table.configure({ resizable: true }), TableRow, TableHeader, TableCell,
      Image.configure({ inline: false }),
      Link.configure({ openOnClick: false, autolink: true }),
      Placeholder.configure({ placeholder: "Start writing…" }),
    ],
    editorProps: { attributes: { class: "doc-body", "aria-label": "Document text", role: "textbox", "aria-multiline": "true" } },
    onUpdate: ({ editor }) => onChange(editor.getHTML()),
  });

  useEffect(() => { if (editor) onEditor(editor); }, [editor, onEditor]);
  if (!editor) return <div className="rounded-xl border border-line bg-white p-8 text-slate">Preparing editor…</div>;

  const c = () => editor.chain().focus();
  const ts = editor.getAttributes("textStyle");
  const heading = [1, 2, 3].find((l) => editor.isActive("heading", { level: l })) ?? 0;

  function addImage(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) return onNotice("Choose an image file (PNG, JPG, GIF or WebP).");
    if (file.size > MAX_IMAGE_BYTES) return onNotice("That image is larger than 1.5 MB. Resize or compress it, then try again.");
    const r = new FileReader();
    r.onload = () => c().setImage({ src: String(r.result), alt: file.name }).run();
    r.onerror = () => onNotice("The image could not be read. Try another file.");
    r.readAsDataURL(file);
  }
  function setLink() {
    const prev = editor!.getAttributes("link").href || "https://";
    const url = window.prompt("Link address (leave empty to remove the link)", prev);
    if (url === null) return;
    if (url.trim() === "" || url.trim() === "https://") c().extendMarkRange("link").unsetLink().run();
    else c().extendMarkRange("link").setLink({ href: url.trim() }).run();
  }

  return (
    <div className="overflow-hidden rounded-xl border border-line bg-white">
      <div className="sticky top-0 z-10 border-b border-line bg-white" role="toolbar" aria-label="Formatting">
        <div className="flex items-center gap-1 overflow-x-auto p-2">
          <Btn label="Undo" on={() => c().undo().run()} disabled={!editor.can().undo()}>↶</Btn>
          <Btn label="Redo" on={() => c().redo().run()} disabled={!editor.can().redo()}>↷</Btn>
          <Sep />
          <select aria-label="Text style" className="field !w-auto !py-1.5" value={heading}
            onChange={(e) => { const l = Number(e.target.value); l ? c().setHeading({ level: l as 1 | 2 | 3 }).run() : c().setParagraph().run(); }}>
            <option value={0}>Paragraph</option><option value={1}>Heading 1</option><option value={2}>Heading 2</option><option value={3}>Heading 3</option>
          </select>
          <select aria-label="Font" className="field !w-auto !py-1.5" value={ts.fontFamily || ""}
            onChange={(e) => (e.target.value ? c().setFontFamily(e.target.value).run() : c().unsetFontFamily().run())}>
            <option value="">Default font</option>
            {FONTS.map((f) => <option key={f} value={f}>{f}</option>)}
          </select>
          <select aria-label="Font size" className="field !w-auto !py-1.5" value={ts.fontSize || ""}
            onChange={(e) => (e.target.value ? c().setFontSize(e.target.value).run() : c().unsetFontSize().run())}>
            <option value="">Size</option>
            {SIZES.map((s) => <option key={s} value={s}>{parseInt(s)}</option>)}
          </select>
          <Sep />
          <Btn label="Bold" on={() => c().toggleBold().run()} active={editor.isActive("bold")}><b>B</b></Btn>
          <Btn label="Italic" on={() => c().toggleItalic().run()} active={editor.isActive("italic")}><i>I</i></Btn>
          <Btn label="Underline" on={() => c().toggleUnderline().run()} active={editor.isActive("underline")}><u>U</u></Btn>
          <Btn label="Strikethrough" on={() => c().toggleStrike().run()} active={editor.isActive("strike")}><s>S</s></Btn>
          <label className="flex h-9 shrink-0 cursor-pointer items-center gap-1 rounded-md px-2 text-sm hover:bg-teal-soft" title="Text colour">
            A<input type="color" aria-label="Text colour" className="h-5 w-5 cursor-pointer border-0 bg-transparent p-0" value={ts.color || "#16262B"} onChange={(e) => c().setColor(e.target.value).run()} />
          </label>
          <label className="flex h-9 shrink-0 cursor-pointer items-center gap-1 rounded-md px-2 text-sm hover:bg-teal-soft" title="Highlight colour">
            ▮<input type="color" aria-label="Highlight colour" className="h-5 w-5 cursor-pointer border-0 bg-transparent p-0" defaultValue="#FBEBD0" onChange={(e) => c().setHighlight({ color: e.target.value }).run()} />
          </label>
          <Sep />
          <Btn label="Align left" on={() => c().setTextAlign("left").run()} active={editor.isActive({ textAlign: "left" })}>⇤</Btn>
          <Btn label="Align centre" on={() => c().setTextAlign("center").run()} active={editor.isActive({ textAlign: "center" })}>↔</Btn>
          <Btn label="Align right" on={() => c().setTextAlign("right").run()} active={editor.isActive({ textAlign: "right" })}>⇥</Btn>
          <Btn label="Justify" on={() => c().setTextAlign("justify").run()} active={editor.isActive({ textAlign: "justify" })}>☰</Btn>
          <Sep />
          <Btn label="Bullet list" on={() => c().toggleBulletList().run()} active={editor.isActive("bulletList")}>• List</Btn>
          <Btn label="Numbered list" on={() => c().toggleOrderedList().run()} active={editor.isActive("orderedList")}>1. List</Btn>
          <Btn label="Quote" on={() => c().toggleBlockquote().run()} active={editor.isActive("blockquote")}>❝</Btn>
          <Btn label="Horizontal line" on={() => c().setHorizontalRule().run()}>―</Btn>
          <Btn label="Page break" on={() => c().setPageBreak().run()}>Page</Btn>
          <Sep />
          <Btn label="Insert table (3 × 3)" on={() => c().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()}>Table</Btn>
          <Btn label="Insert image" on={() => fileRef.current?.click()}>Image</Btn>
          <Btn label="Add or edit link" on={setLink} active={editor.isActive("link")}>Link</Btn>
          <Btn label="Clear formatting" on={() => c().unsetAllMarks().clearNodes().run()}>Clear</Btn>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { addImage(e.target.files?.[0]); e.target.value = ""; }} />
        </div>
        {editor.isActive("table") && (
          <div className="flex items-center gap-1 overflow-x-auto border-t border-line bg-mist p-2 text-xs">
            <span className="shrink-0 px-1 text-slate">Table:</span>
            <Btn label="Add row below" on={() => c().addRowAfter().run()}>+ Row</Btn>
            <Btn label="Add column right" on={() => c().addColumnAfter().run()}>+ Column</Btn>
            <Btn label="Delete row" on={() => c().deleteRow().run()}>− Row</Btn>
            <Btn label="Delete column" on={() => c().deleteColumn().run()}>− Column</Btn>
            <Btn label="Merge or split cells" on={() => c().mergeOrSplit().run()}>Merge/split</Btn>
            <Btn label="Delete table" on={() => c().deleteTable().run()}>Delete table</Btn>
          </div>
        )}
      </div>
      <EditorContent editor={editor} />
    </div>
  );
}
