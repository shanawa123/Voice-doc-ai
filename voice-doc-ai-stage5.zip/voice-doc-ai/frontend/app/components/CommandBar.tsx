"use client";
import { useEffect, useRef, useState } from "react";
import type { Editor } from "@tiptap/react";
import { api } from "@/lib/api";
import { LANGUAGES } from "@/lib/dictation";
import { Action, applyActions, describeDocument } from "@/lib/docEdit";
import { parseLocal } from "@/lib/commands";
import { listenOnce, Listener } from "@/lib/listenOnce";

type Entry = { id: number; you: string; app: string; ok: boolean; ai: boolean };
const EXAMPLES = [
  "Delete the second paragraph", "Make this bold", "Insert today's date", "Add a new page",
  "Change the title to Annual Report", "Correct all spelling mistakes", "Convert this section into bullet points",
  "Make the entire document professional", "Translate this document into Hausa",
];
const LOCAL_EXAMPLES: Record<string, string[]> = {
  ha: ["Sanya wannan rubutu ya yi kauri", "Sanya rubutu karkata", "Ja layi a ƙarƙashin rubutu", "Ƙara sabon shafi", "Saka ranar yau", "Sake"],
  ar: ["اجعل هذا غامقًا", "اجعل هذا مائلًا", "ضع خطًا تحت هذا النص", "أضف صفحة جديدة", "أدرج تاريخ اليوم", "تراجع"],
};

type Props = { getEditor: () => Editor | null; title: string; onTitle: (t: string) => void; onClose: () => void };

export default function CommandBar({ getEditor, title, onTitle, onClose }: Props) {
  const [text, setText] = useState("");
  const [langId, setLangId] = useState("en");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [speak, setSpeak] = useState(false);
  const [ai, setAi] = useState<{ ai: boolean; reason: string } | null>(null);
  const [consent, setConsent] = useState(false);
  const [pending, setPending] = useState<string | null>(null);
  const listener = useRef<Listener | null>(null);
  const last = useRef<{ doc: boolean; title: string | null }>({ doc: false, title: null });
  const nextId = useRef(1);
  const lang = LANGUAGES.find((l) => l.id === langId)!;

  useEffect(() => {
    setConsent(localStorage.getItem("vd_ai_consent") === "yes");
    api<{ ai: boolean; reason: string }>("/command/status").then(setAi).catch(() => setAi({ ai: false, reason: "Could not reach the server." }));
    return () => { listener.current?.cancel(); window.speechSynthesis?.cancel(); };
  }, []);

  function push(you: string, app: string, ok: boolean, usedAi = false) {
    setEntries((e) => [{ id: nextId.current++, you, app, ok, ai: usedAi }, ...e].slice(0, 8));
    if (speak && app && typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(app);
      if (lang.speech) u.lang = lang.speech;
      window.speechSynthesis.speak(u);
    }
  }

  function undoLast() {
    const ed = getEditor();
    if (last.current.doc && ed) ed.commands.undo();
    if (last.current.title !== null) onTitle(last.current.title);
    const did = last.current.doc || last.current.title !== null;
    last.current = { doc: false, title: null };
    return did;
  }

  async function run(instruction: string, skipConsent = false) {
    const q = instruction.trim();
    if (!q) return;
    const ed = getEditor();
    if (!ed) { push(q, "The editor is not ready yet. Try again in a moment.", false); return; }
    setBusy(true);
    try {
      const desc = describeDocument(ed);
      const apply = (actions: Action[], reply: string, usedAi: boolean) => {
        let titleBefore: string | null = null;
        const r = applyActions(ed, actions, desc, (t) => { titleBefore = title; onTitle(t); });
        if (r.error) { push(q, r.error, false, usedAi); return; }
        last.current = { doc: r.changed, title: titleBefore };
        const msg = [reply, ...r.notes].filter(Boolean).join(" ");
        push(q, msg || (r.changed || r.titleChanged ? "Done." : "Nothing needed changing."), true, usedAi);
      };

      const local = parseLocal(q, desc, new Date(), langId);
      if (local && "special" in local) {
        if (local.special === "undo") push(q, undoLast() ? "Undone." : "There is nothing to undo from the commands.", true);
        else { ed.commands.redo(); push(q, "Redone.", true); }
        setText(""); return;
      }
      if (local) { apply(local.actions, local.reply, false); setText(""); return; }

      if (ai && !ai.ai) { push(q, `${ai.reason} Try: delete the second paragraph, make this bold, insert today's date, add a new page, change the title to …`, false); return; }
      if (!consent && !skipConsent) { setPending(q); return; }

      const res = await api<{ actions: Action[]; reply: string }>("/command", {
        method: "POST",
        body: JSON.stringify({
          instruction: q, language: lang.whisper, title,
          blocks: desc.blocks, selection: desc.selection,
          today: new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" }),
        }),
      });
      // The user may have kept typing while the AI worked: refuse to apply edits to a different document.
      const now = describeDocument(ed);
      if (JSON.stringify(now.blocks) !== JSON.stringify(desc.blocks)) {
        push(q, "The document changed while the AI was working, so nothing was applied. Run the command again.", false, true);
      } else apply(res.actions, res.reply, true);
      setText("");
    } catch (e) {
      push(q, (e as Error).message, false);
    } finally { setBusy(false); }
  }

  async function toggleMic() {
    if (listener.current) { listener.current.stop(); return; }
    const l = listenOnce(lang);
    listener.current = l; setListening(true);
    try {
      const said = await l.result;
      if (said) { setText(said); await run(said); }
      else push("", "I did not hear anything. Tap the microphone and try again.", false);
    } catch (e) { push("", (e as Error).message, false); }
    finally { listener.current = null; setListening(false); }
  }

  function allowAi() {
    localStorage.setItem("vd_ai_consent", "yes"); setConsent(true);
    const q = pending; setPending(null);
    if (q) run(q, true);
  }

  return (
    <section className="mb-4 rounded-xl border border-line bg-white p-4" aria-label="Commands">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-semibold">Commands</h2>
        <button className="text-sm text-slate underline" onClick={() => { listener.current?.cancel(); onClose(); }}>Close</button>
      </div>
      <p className="mt-1 text-xs text-slate">Tell the editor what to change. Select text first for “this”. Every command can be undone.</p>

      <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); run(text); }}>
        <input className="field min-w-0 flex-1" value={text} onChange={(e) => setText(e.target.value)} placeholder="Type or speak a command" aria-label="Command" maxLength={1000} disabled={busy} dir="auto" />
        <button type="button" onClick={toggleMic} disabled={busy && !listening} aria-pressed={listening}
          className={`btn shrink-0 ${listening ? "bg-red-600 text-white" : "btn-ghost"}`} aria-label={listening ? "Stop listening" : "Speak a command"}>
          {listening ? "Stop" : "Speak"}
        </button>
        <button className="btn-primary shrink-0" disabled={busy || !text.trim()}>{busy && !listening ? "Working…" : "Run"}</button>
      </form>

      <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
        <label className="flex items-center gap-2">Language
          <select className="field !w-auto !py-1.5" value={langId} onChange={(e) => setLangId(e.target.value)} disabled={listening}>
            {LANGUAGES.map((l) => <option key={l.id} value={l.id}>{l.label}</option>)}
          </select>
        </label>
        <label className="flex items-center gap-2"><input type="checkbox" checked={speak} onChange={(e) => setSpeak(e.target.checked)} /> Read replies aloud</label>
        <button className="btn-ghost !py-1.5" onClick={() => push("Undo", undoLast() ? "Undone." : "There is nothing to undo from the commands.", true)}>Undo last command</button>
      </div>

      {listening && <p className="mt-2 text-sm text-slate" aria-live="polite">Listening… speak now{lang.id === "ha" || lang.id === "auto" ? ", then tap Stop" : ""}.</p>}
      {ai && !ai.ai && <p className="mt-2 rounded-lg bg-amber-soft px-3 py-2 text-xs text-ink">{ai.reason}</p>}

      {pending && (
        <div role="alertdialog" aria-label="Allow AI" className="mt-3 rounded-lg border border-amber bg-amber-soft p-3 text-sm">
          <p>This command needs the AI. The text of this document (not images) is sent through your server to the AI service for this command only. Allow?</p>
          <div className="mt-2 flex gap-2">
            <button className="btn-primary" onClick={allowAi}>Allow and run</button>
            <button className="btn-ghost" onClick={() => setPending(null)}>Cancel</button>
          </div>
        </div>
      )}

      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {(LOCAL_EXAMPLES[langId] || EXAMPLES).map((x) => (
          <button key={x} type="button" onClick={() => setText(x)} className="shrink-0 rounded-full border border-line px-3 py-1 text-xs hover:bg-teal-soft">{x}</button>
        ))}
      </div>

      {entries.length > 0 && (
        <ul className="mt-3 space-y-2" aria-live="polite">
          {entries.map((e) => (
            <li key={e.id} className={`rounded-lg border p-3 text-sm ${e.ok ? "border-line bg-mist" : "border-red-200 bg-red-50"}`}>
              {e.you && <div className="text-xs text-slate" dir="auto">{e.you}{e.ai ? " · AI" : ""}</div>}
              <div className={e.ok ? "" : "text-red-700"} dir="auto">{e.app}</div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
