"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import type { Editor } from "@tiptap/react";
import { api, Doc, timeAgo, useAuth, Version, downloadExport } from "@/lib/api";
import { htmlWordCount, plainToHtml, toHtml } from "@/lib/text";
import RichEditor from "../../components/RichEditor";
import VoicePanel from "../../components/VoicePanel";
import CommandBar from "../../components/CommandBar";

type Status = "loading" | "saved" | "unsaved" | "saving" | "error";

export default function EditorPage() {
  const user = useAuth();
  const router = useRouter();
  const { id } = useParams<{ id: string }>();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [initialHtml, setInitialHtml] = useState("");
  const [status, setStatus] = useState<Status>("loading");
  const [error, setError] = useState("");
  const [versions, setVersions] = useState<Version[] | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [showVoice, setShowVoice] = useState(false);
  const [showCmd, setShowCmd] = useState(false);
  const [exporting, setExporting] = useState(false);
  useEffect(() => { if (new URLSearchParams(window.location.search).get("voice") === "1") setShowVoice(true); }, []);
  const lastSaved = useRef({ title: "", content: "" });
  const ready = useRef(false);
  const editorRef = useRef<Editor | null>(null);
  const onEditor = useCallback((e: Editor) => { editorRef.current = e; }, []);
  const onNotice = useCallback((m: string) => setError(m), []);

  useEffect(() => {
    if (!user) return;
    api<Doc>(`/documents/${id}`)
      .then((d) => {
        const html = toHtml(d.content);
        setTitle(d.title); setContent(html); setInitialHtml(html);
        lastSaved.current = { title: d.title, content: html };
        ready.current = true; setStatus("saved");
      })
      .catch((e) => { setError(e.message); setStatus("error"); });
  }, [user, id]);

  function loadVersions() {
    api<Version[]>(`/documents/${id}/versions`).then(setVersions).catch((e) => setError(e.message));
  }

  const save = useCallback(async (snapshot: boolean) => {
    setStatus("saving"); setError("");
    try {
      const d = await api<Doc>(`/documents/${id}`, { method: "PUT", body: JSON.stringify({ title, content, snapshot }) });
      lastSaved.current = { title: d.title, content: d.content };
      setStatus("saved");
      if (showHistory) loadVersions();
    } catch (e) { setError((e as Error).message); setStatus("error"); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, title, content, showHistory]);

  // Autosave 1.5 s after the last change
  useEffect(() => {
    if (!ready.current) return;
    if (title === lastSaved.current.title && content === lastSaved.current.content) return;
    setStatus("unsaved");
    const t = setTimeout(() => save(false), 1500);
    return () => clearTimeout(t);
  }, [title, content, save]);

  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => { if (status === "unsaved" || status === "saving") e.preventDefault(); };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, [status]);

  async function restore(v: Version) {
    if (!confirm("Restore this version? Your current text is saved to history first.")) return;
    try {
      const d = await api<Doc>(`/documents/${id}/versions/${v.id}/restore`, { method: "POST" });
      const html = toHtml(d.content);
      setTitle(d.title); setContent(html);
      editorRef.current?.commands.setContent(html, false);
      lastSaved.current = { title: d.title, content: html };
      setStatus("saved"); loadVersions();
    } catch (e) { setError((e as Error).message); }
  }

  async function remove() {
    if (!confirm("Delete this document and its version history? This cannot be undone.")) return;
    try { await api(`/documents/${id}`, { method: "DELETE" }); router.replace("/"); }
    catch (e) { setError((e as Error).message); }
  }

  function insertDictation(text: string) {
    const ed = editorRef.current;
    if (!ed) { setError("The editor is not ready yet. Try again in a moment."); return; }
    ed.chain().focus().insertContent(plainToHtml(text)).run();
  }

  async function exportAs(format: string) {
    setExporting(true); setError("");
    try { await downloadExport(format, title, editorRef.current?.getHTML() ?? content); }
    catch (e) { setError((e as Error).message); }
    finally { setExporting(false); }
  }

  if (!user || status === "loading") return <main className="p-8 text-slate">Loading document…</main>;

  const label = { saved: "All changes saved", unsaved: "Unsaved changes", saving: "Saving…", error: "Not saved", loading: "" }[status];

  return (
    <div className="flex min-h-screen flex-col">
      <header className="relative border-b border-line bg-white">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-2 px-4 py-3">
          <button className="btn-ghost !px-3" onClick={() => router.push("/")} aria-label="Back to dashboard">Back</button>
          <input className="min-w-0 flex-1 bg-transparent font-serif text-xl outline-none" value={title} onChange={(e) => setTitle(e.target.value)} aria-label="Document title" maxLength={300} />
          <span className={`text-xs ${status === "error" ? "text-red-700" : "text-slate"}`} aria-live="polite">{label}</span>
          <button className="btn-primary" onClick={() => save(true)} disabled={status === "saving"}>Save</button>
          <button className="btn-ghost" onClick={() => { setShowVoice(!showVoice); setShowCmd(false); }} aria-pressed={showVoice}>Dictate</button>
          <button className="btn-ghost" onClick={() => { setShowCmd(!showCmd); setShowVoice(false); }} aria-pressed={showCmd}>Commands</button>
          <button className="btn-ghost" onClick={() => { setShowHistory(!showHistory); if (!showHistory) loadVersions(); }}>History</button>
          <div className="flex flex-wrap gap-1">
            {(["docx", "pdf", "xlsx", "pptx", "txt"] as const).map((fmt) => <button key={fmt} className="btn-ghost !px-2" disabled={exporting} onClick={() => exportAs(fmt)}>{exporting ? "Exporting…" : `.${fmt}`}</button>)}
          </div>
          <button className="btn-danger" onClick={remove}>Delete</button>
        </div>
        {error && (
          <p role="alert" className="mx-auto flex max-w-5xl items-center justify-between bg-red-50 px-4 py-2 text-sm text-red-700">
            <span>{error}</span><button className="underline" onClick={() => setError("")}>Dismiss</button>
          </p>
        )}
      </header>

      <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-4 px-4 py-5 lg:flex-row">
        <main className="min-w-0 flex-1">
          {showVoice && <VoicePanel onInsert={insertDictation} onClose={() => setShowVoice(false)} />}
          {showCmd && <CommandBar getEditor={() => editorRef.current} title={title} onTitle={setTitle} onClose={() => setShowCmd(false)} />}
          <RichEditor initialHtml={initialHtml} onChange={setContent} onEditor={onEditor} onNotice={onNotice} />
          <p className="mt-2 text-xs text-slate">{htmlWordCount(content)} words</p>
        </main>

        {showHistory && (
          <aside className="w-full shrink-0 rounded-xl border border-line bg-white p-4 lg:w-72" aria-label="Version history">
            <h2 className="font-semibold">Version history</h2>
            {versions === null ? <p className="mt-2 text-sm text-slate">Loading…</p>
              : versions.length === 0 ? <p className="mt-2 text-sm text-slate">No versions yet. Press Save to store one, or keep editing: a version is stored every few minutes.</p>
              : <ul className="mt-3 max-h-[60vh] space-y-2 overflow-y-auto">
                  {versions.map((v) => (
                    <li key={v.id} className="rounded-lg border border-line p-3">
                      <div className="text-xs text-slate">{timeAgo(v.created)}</div>
                      <div className="truncate text-sm font-medium">{v.title}</div>
                      <div className="line-clamp-2 text-xs text-slate">{v.preview || "Empty"}</div>
                      <button className="mt-2 text-xs font-medium text-teal underline" onClick={() => restore(v)}>Restore</button>
                    </li>
                  ))}
                </ul>}
          </aside>
        )}
      </div>
    </div>
  );
}
