"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, setToken, User } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(""); setBusy(true);
    try {
      const body = mode === "login" ? { email, password } : { name, email, password };
      const res = await api<{ token: string; user: User }>(`/auth/${mode}`, { method: "POST", body: JSON.stringify(body) });
      setToken(res.token);
      router.replace("/");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10">
      <h1 className="font-serif text-4xl font-medium">Voice Doc AI</h1>
      <p className="mt-2 text-slate">Speak it, write it, fix it. Your documents stay private to your account.</p>

      <form onSubmit={submit} className="mt-8 space-y-4 rounded-2xl border border-line bg-white p-5">
        <h2 className="text-lg font-semibold">{mode === "login" ? "Sign in" : "Create your account"}</h2>
        {mode === "register" && (
          <label className="block text-sm">Full name
            <input className="field mt-1" value={name} onChange={(e) => setName(e.target.value)} required autoComplete="name" />
          </label>
        )}
        <label className="block text-sm">Email
          <input className="field mt-1" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
        </label>
        <label className="block text-sm">Password {mode === "register" && <span className="text-slate">(8 characters or more)</span>}
          <input className="field mt-1" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={mode === "register" ? 8 : 1} autoComplete={mode === "login" ? "current-password" : "new-password"} />
        </label>
        {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>
          {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
        </button>
        <button type="button" className="w-full text-sm text-teal underline" onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}>
          {mode === "login" ? "New here? Create an account" : "Already registered? Sign in"}
        </button>
      </form>
    </main>
  );
}
