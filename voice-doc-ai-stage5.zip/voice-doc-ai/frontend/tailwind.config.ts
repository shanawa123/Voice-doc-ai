import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#16262B", slate: "#5B6B71", mist: "#EEF3F4", line: "#D5DFE1",
        teal: { DEFAULT: "#0E5A6B", dark: "#0A4351", soft: "#DCEBEE" },
        amber: { DEFAULT: "#D9902B", soft: "#FBEBD0" },
      },
      fontFamily: { serif: ["Newsreader", "Georgia", "serif"], sans: ["Instrument Sans", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
export default config;
