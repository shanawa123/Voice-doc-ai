"""VOICE DOC AI - Stage 1 backend: auth, documents, autosave, version history."""
import hashlib
import hmac
import html as htmllib
import importlib.util
import os
import re
import secrets
import sqlite3
import tempfile
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import jwt
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

import command_engine as engine

BASE_DIR = Path(__file__).parent
DB_PATH = Path(os.getenv("VOICEDOC_DB", BASE_DIR / "voicedoc.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
MAX_CONTENT = 5_000_000  # characters per document
SNAPSHOT_GAP = timedelta(minutes=5)  # automatic version every 5 min of editing


def load_secret() -> str:
    """Load a stable signing key; create a private local key for development if absent."""
    env = os.getenv("VOICEDOC_SECRET", "").strip()
    if env:
        if len(env) < 32:
            raise RuntimeError("VOICEDOC_SECRET must contain at least 32 characters.")
        return env

    f = BASE_DIR / ".secret"
    try:
        # O_EXCL avoids two workers racing to create different signing keys.
        fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        pass
    else:
        with os.fdopen(fd, "w") as stream:
            stream.write(secrets.token_hex(32))
    try:
        os.chmod(f, 0o600)
    except OSError:
        pass
    value = f.read_text().strip()
    if len(value) < 32:
        raise RuntimeError("backend/.secret is missing or too short. Set VOICEDOC_SECRET to a secure value.")
    return value


SECRET = load_secret()


_BLOCK_END = re.compile(r"</(p|h[1-6]|li|tr|div|blockquote)>|<br\s*/?>", re.I)
_TAG = re.compile(r"<[^>]*>?")


def plain_preview(content: str, n: int = 140) -> str:
    """Readable preview from stored text or HTML (strips tags, including a tag cut off by SQL substr)."""
    text = _BLOCK_END.sub(" ", content)
    text = htmllib.unescape(_TAG.sub("", text))
    return re.sub(r"\s+", " ", text).strip()[:n]


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  created TEXT NOT NULL,
  updated TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS versions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  created TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_docs_user ON documents(user_id, updated DESC);
CREATE INDEX IF NOT EXISTS idx_ver_doc ON versions(document_id, created DESC);
"""

with sqlite3.connect(DB_PATH) as _c:
    _c.executescript(SCHEMA)

app = FastAPI(title="Voice Doc AI API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("VOICEDOC_ORIGINS", "http://localhost:3000").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------- auth helpers ----------------
def hash_password(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 200_000).hex()


def make_token(user_id: int) -> str:
    exp = datetime.now(timezone.utc) + timedelta(days=14)
    return jwt.encode({"sub": str(user_id), "exp": exp}, SECRET, algorithm="HS256")


def current_user(authorization: Optional[str] = Header(None), db: sqlite3.Connection = Depends(get_db)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Please sign in to continue.")
    try:
        payload = jwt.decode(authorization[7:], SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(401, "Your session has expired. Please sign in again.")
    row = db.execute("SELECT id, name, email FROM users WHERE id=?", (int(payload["sub"]),)).fetchone()
    if not row:
        raise HTTPException(401, "Account not found.")
    return dict(row)


class RegisterIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: str = Field(min_length=5, max_length=200)
    password: str = Field(min_length=8, max_length=200)


class LoginIn(BaseModel):
    email: str
    password: str


@app.post("/api/auth/register")
def register(body: RegisterIn, db: sqlite3.Connection = Depends(get_db)):
    name = body.name.strip()
    email = body.email.strip().lower()
    if not name:
        raise HTTPException(422, "Enter your name.")
    if len(email) > 200 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise HTTPException(422, "Enter a valid email address.")
    if db.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
        raise HTTPException(409, "An account with this email already exists. Sign in instead.")
    salt = secrets.token_hex(16)
    cur = db.execute(
        "INSERT INTO users(name,email,salt,password_hash,created) VALUES(?,?,?,?,?)",
        (name, email, salt, hash_password(body.password, salt), now()),
    )
    db.commit()
    return {"token": make_token(cur.lastrowid), "user": {"id": cur.lastrowid, "name": name, "email": email}}


@app.post("/api/auth/login")
def login(body: LoginIn, db: sqlite3.Connection = Depends(get_db)):
    row = db.execute("SELECT * FROM users WHERE email=?", (body.email.strip().lower(),)).fetchone()
    if not row or not hmac.compare_digest(row["password_hash"], hash_password(body.password, row["salt"])):
        raise HTTPException(401, "Email or password is incorrect.")
    return {"token": make_token(row["id"]), "user": {"id": row["id"], "name": row["name"], "email": row["email"]}}


@app.get("/api/auth/me")
def me(user=Depends(current_user)):
    return user


# ---------------- documents ----------------
class DocIn(BaseModel):
    title: str = Field(default="Untitled document", max_length=300)
    content: str = Field(default="", max_length=MAX_CONTENT)


class DocUpdate(DocIn):
    snapshot: bool = False  # True = user pressed Save: always store a version


def own_doc(db: sqlite3.Connection, doc_id: int, user_id: int) -> sqlite3.Row:
    row = db.execute("SELECT * FROM documents WHERE id=? AND user_id=?", (doc_id, user_id)).fetchone()
    if not row:
        raise HTTPException(404, "Document not found.")
    return row


def add_version(db: sqlite3.Connection, doc: sqlite3.Row):
    db.execute(
        "INSERT INTO versions(document_id,title,content,created) VALUES(?,?,?,?)",
        (doc["id"], doc["title"], doc["content"], now()),
    )


@app.get("/api/documents")
def list_documents(user=Depends(current_user), db: sqlite3.Connection = Depends(get_db)):
    rows = db.execute(
        "SELECT id,title,substr(content,1,3000) AS preview,updated FROM documents WHERE user_id=? ORDER BY updated DESC",
        (user["id"],),
    ).fetchall()
    return [{**dict(r), "preview": plain_preview(r["preview"])} for r in rows]


@app.post("/api/documents", status_code=201)
def create_document(body: DocIn, user=Depends(current_user), db: sqlite3.Connection = Depends(get_db)):
    t = now()
    cur = db.execute(
        "INSERT INTO documents(user_id,title,content,created,updated) VALUES(?,?,?,?,?)",
        (user["id"], body.title.strip() or "Untitled document", body.content, t, t),
    )
    db.commit()
    return dict(own_doc(db, cur.lastrowid, user["id"]))


@app.get("/api/documents/{doc_id}")
def get_document(doc_id: int, user=Depends(current_user), db: sqlite3.Connection = Depends(get_db)):
    return dict(own_doc(db, doc_id, user["id"]))


@app.put("/api/documents/{doc_id}")
def update_document(doc_id: int, body: DocUpdate, user=Depends(current_user), db: sqlite3.Connection = Depends(get_db)):
    doc = own_doc(db, doc_id, user["id"])
    changed = doc["title"] != body.title or doc["content"] != body.content
    if changed:
        last = db.execute(
            "SELECT created FROM versions WHERE document_id=? ORDER BY id DESC LIMIT 1", (doc_id,)
        ).fetchone()
        stale = (not last) or (datetime.now(timezone.utc) - datetime.fromisoformat(last["created"]) > SNAPSHOT_GAP)
        if body.snapshot or stale:
            add_version(db, doc)  # keep the state we are about to overwrite
    db.execute(
        "UPDATE documents SET title=?,content=?,updated=? WHERE id=?",
        (body.title.strip() or "Untitled document", body.content, now(), doc_id),
    )
    db.commit()
    return dict(own_doc(db, doc_id, user["id"]))


@app.delete("/api/documents/{doc_id}", status_code=204)
def delete_document(doc_id: int, user=Depends(current_user), db: sqlite3.Connection = Depends(get_db)):
    own_doc(db, doc_id, user["id"])
    db.execute("DELETE FROM documents WHERE id=?", (doc_id,))  # versions cascade
    db.commit()


@app.get("/api/documents/{doc_id}/versions")
def list_versions(doc_id: int, user=Depends(current_user), db: sqlite3.Connection = Depends(get_db)):
    own_doc(db, doc_id, user["id"])
    rows = db.execute(
        "SELECT id,title,substr(content,1,3000) AS preview,created FROM versions WHERE document_id=? ORDER BY id DESC LIMIT 100",
        (doc_id,),
    ).fetchall()
    return [{**dict(r), "preview": plain_preview(r["preview"])} for r in rows]


@app.post("/api/documents/{doc_id}/versions/{version_id}/restore")
def restore_version(doc_id: int, version_id: int, user=Depends(current_user), db: sqlite3.Connection = Depends(get_db)):
    doc = own_doc(db, doc_id, user["id"])
    ver = db.execute("SELECT * FROM versions WHERE id=? AND document_id=?", (version_id, doc_id)).fetchone()
    if not ver:
        raise HTTPException(404, "Version not found.")
    add_version(db, doc)  # restoring never loses the current text
    db.execute("UPDATE documents SET title=?,content=?,updated=? WHERE id=?", (ver["title"], ver["content"], now(), doc_id))
    db.commit()
    return dict(own_doc(db, doc_id, user["id"]))


@app.get("/api/health")
def health():
    return {"ok": True}


# ---------------- speech-to-text (Whisper, runs on your own server) ----------------
WHISPER_MODEL = os.getenv("VOICEDOC_WHISPER_MODEL", "small")  # tiny | base | small | medium | large-v3
WHISPER_DEVICE = os.getenv("VOICEDOC_WHISPER_DEVICE", "cpu")
WHISPER_COMPUTE = os.getenv("VOICEDOC_WHISPER_COMPUTE", "int8")
MAX_AUDIO = 25 * 1024 * 1024
LANGS = {"auto", "en", "ha", "ar", "fr", "es", "sw"}
AUDIO_EXT = {".webm", ".m4a", ".mp4", ".ogg", ".wav", ".mp3", ".opus"}
_whisper = None
_whisper_lock = threading.Lock()


def whisper_available() -> bool:
    return importlib.util.find_spec("faster_whisper") is not None


def get_whisper():
    global _whisper
    with _whisper_lock:
        if _whisper is None:
            from faster_whisper import WhisperModel

            _whisper = WhisperModel(WHISPER_MODEL, device=WHISPER_DEVICE, compute_type=WHISPER_COMPUTE)
    return _whisper


@app.get("/api/transcribe/status")
def transcribe_status(user=Depends(current_user)):
    return {"available": whisper_available(), "model": WHISPER_MODEL}


@app.post("/api/transcribe")
def transcribe(audio: UploadFile = File(...), language: str = Form("auto"), user=Depends(current_user)):
    """The user presses 'Transcribe' to send a recording here; nothing is uploaded automatically."""
    if language not in LANGS:
        raise HTTPException(422, "That language is not supported.")
    if not whisper_available():
        raise HTTPException(503, "Whisper is not installed on the server. Run: pip install -r requirements-whisper.txt")
    suffix = Path(audio.filename or "").suffix.lower()
    if suffix not in AUDIO_EXT:
        suffix = ".webm"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        size = 0
        while chunk := audio.file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_AUDIO:
                raise HTTPException(413, "The recording is larger than 25 MB. Record it in shorter parts.")
            tmp.write(chunk)
        tmp.close()
        if size == 0:
            raise HTTPException(422, "The recording is empty.")
        try:
            segments, info = get_whisper().transcribe(
                tmp.name, language=None if language == "auto" else language, vad_filter=True, beam_size=5
            )
            text = " ".join(seg.text.strip() for seg in segments).strip()
        except Exception as e:  # model download, decoding, memory
            raise HTTPException(
                503,
                f"Transcription failed ({type(e).__name__}). On the first run the server needs internet once to download the speech model.",
            )
        return {"text": text, "language": info.language, "duration": round(info.duration, 1)}
    finally:
        tmp.close()
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


# ---------------- voice / text commands ----------------
class BlockIn(BaseModel):
    i: int
    type: str = Field(max_length=30)
    level: Optional[int] = None
    text: str = Field(default="", max_length=200_000)
    items: Optional[list] = None
    align: Optional[str] = None


class SelectionIn(BaseModel):
    blocks: list = []
    text: str = Field(default="", max_length=20_000)
    cursor_block: Optional[int] = None


class CommandIn(BaseModel):
    instruction: str = Field(min_length=1, max_length=1000)
    language: str = Field(default="en", max_length=10)
    title: str = Field(default="", max_length=300)
    blocks: list[BlockIn]
    selection: SelectionIn = Field(default_factory=SelectionIn)
    today: str = Field(default="", max_length=60)


@app.get("/api/command/status")
def command_status(user=Depends(current_user)):
    ok, reason = engine.ai_status()
    return {"ai": ok, "reason": reason, "model": engine.AI_MODEL}


@app.post("/api/command")
def run_command(body: CommandIn, user=Depends(current_user)):
    """Receives the document text only after the user agreed in the app; nothing is stored."""
    ok, reason = engine.ai_status()
    if not ok:
        raise HTTPException(503, reason)
    if len(body.blocks) > 3000:
        raise HTTPException(413, "This document has too many sections for AI commands. Select a smaller part.")
    if not engine.within_rate_limit(user["id"]):
        raise HTTPException(429, "Too many commands. Wait a minute and try again.")
    selected = {int(i) for i in body.selection.blocks if isinstance(i, int)}
    blocks = engine.fit_blocks([b.model_dump() for b in body.blocks], selected)
    try:
        result = engine.run_llm(
            body.instruction, body.language, body.title, blocks, body.selection.model_dump(), body.today
        )
    except ImportError:
        raise HTTPException(503, "The server is missing the AI package. Run: pip install -r requirements-ai.txt")
    except Exception:
        raise HTTPException(502, "The AI service did not respond. Try again in a moment.")
    actions, dropped = engine.clean_actions(result.get("actions", []), blocks)
    reply = str(result.get("reply", ""))[:500]
    if dropped:
        reply = (reply + " Some changes were skipped because they would have damaged tables, images or parts of the document I could not see.").strip()
    return {"actions": actions, "reply": reply}

# ---------------- Stage 5: universal document import / export / OCR ----------------
from fastapi.responses import StreamingResponse
from io import BytesIO
from html.parser import HTMLParser

MAX_IMPORT = 20 * 1024 * 1024
ALLOWED_IMPORTS = {".docx", ".pdf", ".xlsx", ".pptx", ".txt", ".md"}


def _esc(value: str) -> str:
    return htmllib.escape(value or "", quote=True)


def _text_html(value: str) -> str:
    chunks = [line.strip() for line in (value or "").replace("\r", "").split("\n")]
    return "".join(f"<p>{_esc(line) if line else '<br>'}</p>" for line in chunks) or "<p></p>"


def _read_upload(upload: UploadFile) -> bytes:
    data = upload.file.read(MAX_IMPORT + 1)
    if len(data) > MAX_IMPORT:
        raise HTTPException(413, "File is larger than 20 MB. Please use a smaller file.")
    if not data:
        raise HTTPException(422, "The uploaded file is empty.")
    return data


@app.post("/api/import")
def import_document(file: UploadFile = File(...), user=Depends(current_user)):
    """Parse an uploaded office/PDF/text file into safe editor HTML; no file is retained."""
    filename = Path(file.filename or "document").name
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_IMPORTS:
        raise HTTPException(415, "Supported formats: DOCX, PDF, XLSX, PPTX, TXT and MD.")
    raw = _read_upload(file)
    title = Path(filename).stem[:300] or "Imported document"
    try:
        if ext in {".txt", ".md"}:
            html = _text_html(raw.decode("utf-8-sig"))
        elif ext == ".docx":
            from docx import Document
            doc = Document(BytesIO(raw))
            parts = []
            for p in doc.paragraphs:
                tag = "h1" if p.style and p.style.name.lower().startswith("title") else "h2" if p.style and p.style.name.lower().startswith("heading 1") else "p"
                parts.append(f"<{tag}>{_esc(p.text)}</{tag}>")
            for table in doc.tables:
                parts.append("<table><tbody>")
                for row in table.rows:
                    parts.append("<tr>" + "".join(f"<td>{_esc(cell.text)}</td>" for cell in row.cells) + "</tr>")
                parts.append("</tbody></table>")
            html = "".join(parts) or "<p></p>"
        elif ext == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(BytesIO(raw))
            if len(reader.pages) > 300:
                raise HTTPException(413, "PDF has more than 300 pages. Split it into smaller files.")
            html = "".join(f"<h2>Page {i + 1}</h2>" + _text_html(page.extract_text() or "[No selectable text on this page. Try OCR for scanned PDFs.] ") for i, page in enumerate(reader.pages))
        elif ext == ".xlsx":
            from openpyxl import load_workbook
            wb = load_workbook(BytesIO(raw), read_only=True, data_only=True)
            parts = []
            for ws in wb.worksheets[:30]:
                parts.append(f"<h2>{_esc(ws.title)}</h2><table><tbody>")
                for row in ws.iter_rows(max_row=500, max_col=50, values_only=True):
                    vals = list(row)
                    while vals and vals[-1] is None: vals.pop()
                    if vals:
                        parts.append("<tr>" + "".join(f"<td>{_esc(str(v) if v is not None else '')}</td>" for v in vals) + "</tr>")
                parts.append("</tbody></table>")
            wb.close()
            html = "".join(parts) or "<p>Workbook is empty.</p>"
        elif ext == ".pptx":
            from pptx import Presentation
            prs = Presentation(BytesIO(raw))
            if len(prs.slides) > 300:
                raise HTTPException(413, "Presentation has more than 300 slides. Split it into smaller files.")
            parts = []
            for i, slide in enumerate(prs.slides):
                parts.append(f"<h2>Slide {i + 1}</h2>")
                for shape in slide.shapes:
                    if getattr(shape, "has_text_frame", False):
                        for p in shape.text_frame.paragraphs:
                            if p.text.strip(): parts.append(f"<p>{_esc(p.text)}</p>")
                    if getattr(shape, "has_table", False):
                        parts.append("<table><tbody>")
                        for row in shape.table.rows:
                            parts.append("<tr>" + "".join(f"<td>{_esc(cell.text)}</td>" for cell in row.cells) + "</tr>")
                        parts.append("</tbody></table>")
            html = "".join(parts) or "<p>Presentation is empty.</p>"
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(422, f"Could not read this {ext[1:].upper()} file. It may be damaged or password-protected.") from exc
    return {"title": title, "content": html, "source_format": ext[1:], "filename": filename}


class _VisibleText(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts = []
    def handle_data(self, data):
        if data.strip(): self.parts.append(data.strip())
    def handle_starttag(self, tag, attrs):
        if tag in {"p", "h1", "h2", "h3", "tr", "li", "br", "div"}: self.parts.append("\n")
    def text(self): return "\n".join(x for x in self.parts if x != "\n").strip()


class ExportIn(BaseModel):
    title: str = Field(default="Document", max_length=300)
    content: str = Field(default="", max_length=MAX_CONTENT)


@app.post("/api/export/{fmt}")
def export_document(fmt: str, body: ExportIn, user=Depends(current_user)):
    """Create a downloadable Office/PDF rendition from the current editor content."""
    fmt = fmt.lower()
    if fmt not in {"docx", "pdf", "txt", "md", "xlsx", "pptx"}:
        raise HTTPException(415, "Export formats: DOCX, PDF, TXT, MD, XLSX and PPTX.")
    parser = _VisibleText(); parser.feed(body.content)
    text_content = parser.text()
    output = BytesIO()
    try:
        if fmt == "docx":
            from docx import Document
            doc = Document(); doc.add_heading(body.title, 0)
            for line in text_content.splitlines(): doc.add_paragraph(line)
            doc.save(output)
            mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        elif fmt == "pdf":
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib.units import mm
            from xml.sax.saxutils import escape
            styles = getSampleStyleSheet(); story = [Paragraph(escape(body.title), styles["Title"]), Spacer(1, 8 * mm)]
            for line in text_content.splitlines(): story.append(Paragraph(escape(line) or "&nbsp;", styles["BodyText"]))
            SimpleDocTemplate(output, pagesize=A4).build(story)
            mime = "application/pdf"
        elif fmt in {"txt", "md"}:
            output.write((body.title + "\n\n" + text_content).encode("utf-8")); mime = "text/plain; charset=utf-8"
        elif fmt == "xlsx":
            from openpyxl import Workbook
            wb = Workbook(); ws = wb.active; ws.title = "Document"
            ws.append([body.title])
            for line in text_content.splitlines(): ws.append([line])
            wb.save(output); mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        else:
            from pptx import Presentation
            from pptx.util import Inches
            prs = Presentation(); chunks = text_content.splitlines() or [body.title]
            for start in range(0, len(chunks), 6):
                slide = prs.slides.add_slide(prs.slide_layouts[1])
                slide.shapes.title.text = body.title if start == 0 else f"{body.title} ({start // 6 + 1})"
                frame = slide.placeholders[1].text_frame; frame.text = chunks[start]
                for line in chunks[start + 1:start + 6]: frame.add_paragraph().text = line
            prs.save(output); mime = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    except ImportError as exc:
        raise HTTPException(503, f"Export dependency missing for {fmt.upper()}. Install backend requirements.") from exc
    output.seek(0)
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", body.title).strip("_")[:80] or "document"
    return StreamingResponse(output, media_type=mime, headers={"Content-Disposition": f'attachment; filename="{safe}.{fmt}"'})


@app.post("/api/ocr")
def ocr_image(file: UploadFile = File(...), user=Depends(current_user)):
    """Optional OCR for a user-selected image. Requires Tesseract installed on the host."""
    raw = _read_upload(file)
    try:
        from PIL import Image
        import pytesseract
        image = Image.open(BytesIO(raw)).convert("RGB")
        if image.width * image.height > 25_000_000:
            raise HTTPException(413, "Image resolution is too large. Resize it and try again.")
        extracted = pytesseract.image_to_string(image)
    except HTTPException:
        raise
    except ImportError as exc:
        raise HTTPException(503, "OCR is optional. Install requirements-ocr.txt and the Tesseract system application.") from exc
    except Exception as exc:
        raise HTTPException(422, "Could not read this image. Use a clear JPG or PNG photo.") from exc
    return {"text": extracted.strip()}
