# Voice Doc AI — Stage 4

A web-based document editor with accounts, private documents, rich-text editing, version history, speech dictation, and voice/text editing commands.

## Included features

- Email/password registration and login; private user-owned documents.
- Rich-text editing with headings, text styling, lists, tables, images, links, undo and redo.
- Automatic saving, manual version snapshots, history and restore.
- Browser live dictation where supported.
- Optional server-side Whisper transcription (including Hausa, depending on model quality).
- Local commands for common formatting and document operations.
- Optional Anthropic-powered commands for rewriting, translation and other supported edits.

> Upload/import, OCR scanning, and a general-purpose writing assistant are not included in Stage 4.

## Requirements

- Python 3.10+
- Node.js 18.17+ (Node 20 LTS recommended)
- npm

## Start the backend

```bash
cd backend
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

The backend creates `backend/.secret` on first start for local development. Keep this file private and do not commit or share it. Set `VOICEDOC_SECRET` to a stable random value of at least 32 characters in production. Changing the signing key invalidates existing login tokens.

## Start the frontend

In a second terminal:

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

Open http://localhost:3000. The default API URL is `http://localhost:8000`. If frontend and backend are on different hosts, set `NEXT_PUBLIC_API_URL` in `frontend/.env.local` and configure `VOICEDOC_ORIGINS` on the backend. Restart Next.js after changing environment variables.

## Optional AI commands

Install the AI dependency from the backend directory:

```bash
pip install -r requirements-ai.txt
```

Set `ANTHROPIC_API_KEY` in the backend process environment. Optionally set `VOICEDOC_AI_MODEL` to a model identifier supported by your Anthropic account. Never put the API key in frontend code or a `NEXT_PUBLIC_` variable.

The application should request consent before sending document text to the AI service. Do not include confidential documents unless you are comfortable with the configured provider processing their text. Images are not included in the AI request.

## Optional Whisper transcription

```bash
pip install -r requirements-whisper.txt
```

Environment settings:

- `VOICEDOC_WHISPER_MODEL`: `tiny`, `base`, `small`, `medium`, or `large-v3` (default `small`). Larger models require more memory and processing time.
- `VOICEDOC_WHISPER_DEVICE`: `cpu` or `cuda` (default `cpu`).
- `VOICEDOC_WHISPER_COMPUTE`: for example `int8` on CPU or `float16` on a supported GPU.

The first transcription may download model files and therefore needs internet access. Microphone access generally requires HTTPS, except on localhost.

## Backend environment variables

| Variable | Purpose |
|---|---|
| `VOICEDOC_SECRET` | Stable JWT signing secret; at least 32 characters. |
| `VOICEDOC_ORIGINS` | Comma-separated allowed frontend origins; default `http://localhost:3000`. |
| `VOICEDOC_DB` | SQLite database path; default `backend/voicedoc.db`. |
| `ANTHROPIC_API_KEY` | Enables AI commands when the optional package is installed. |
| `VOICEDOC_AI_MODEL` | Anthropic model identifier. |
| `VOICEDOC_WHISPER_MODEL` | Whisper model size. |
| `VOICEDOC_WHISPER_DEVICE` | Whisper compute device. |
| `VOICEDOC_WHISPER_COMPUTE` | Whisper compute type. |

## Verification and production notes

Run backend syntax checks with `python -m py_compile main.py command_engine.py` from `backend/`. Run frontend checks with `npm run build` from `frontend/` after dependencies are installed.

This is a development-stage application, not yet security-audited for public production use. Before deployment: use HTTPS, set strong environment secrets, restrict CORS to exact trusted origins, use persistent private storage and backups, add login/registration abuse protection, and test authorization and data isolation. Do not distribute a populated database or secret file.

## Stage 4.2 — multilingual local voice commands

This update adds a small set of deterministic, offline document commands for Hausa and Arabic, alongside the existing English command parser. These commands run in the browser and do not send document content to the AI service.

### Hausa examples
- `Sanya wannan rubutu ya yi kauri` — bold the current selection or cursor paragraph.
- `Sanya rubutu karkata` — italicise the current selection or cursor paragraph.
- `Ja layi a ƙarƙashin rubutu` — underline the current selection or cursor paragraph.
- `Ƙara sabon shafi` — insert a page break.
- `Saka ranar yau` — insert today's date.
- `Sake` — undo the last command.
- `Maido` — redo.

### Arabic examples
- `اجعل هذا غامقًا` — bold the current selection or cursor paragraph.
- `اجعل هذا مائلًا` — italicise the current selection or cursor paragraph.
- `ضع خطًا تحت هذا النص` — underline the current selection or cursor paragraph.
- `أضف صفحة جديدة` — insert a page break.
- `أدرج تاريخ اليوم` — insert today's date.
- `تراجع` — undo; `إعادة` — redo.

Choose the matching command language in the Commands panel before speaking or typing these phrases. Browser speech recognition support varies; Hausa and Auto-detect use the server-side Whisper transcription route. AI-powered requests still require the configured AI provider and explicit consent.

### Verification note
Backend Python files pass `compileall`. The frontend TypeScript production build has not been verified in this environment because frontend dependencies are not installed. Run `npm install` and `npm run build` inside `frontend/` before deployment.

## Stage 5 — Universal document import and export

Stage 5 adds authenticated upload and export routes. Imported files are parsed in memory and are not retained as uploaded originals. The extracted content is placed into a new editable Voice Doc AI document.

### Import formats
- Word `.docx` — paragraphs and tables.
- PDF `.pdf` — selectable page text. Scanned/image-only PDFs may have no extractable text; use image OCR for individual JPG/PNG pages.
- Excel `.xlsx` — worksheet names and cell values rendered as editable tables (up to 30 sheets, 500 rows and 50 columns per sheet).
- PowerPoint `.pptx` — slide text and tables.
- Plain text `.txt` and Markdown `.md`.

Maximum import size is 20 MB. Password-protected or damaged Office/PDF files may not be readable. Formatting, embedded images, charts, formulas and slide layouts are not guaranteed to survive conversion; this is an editable-content import, not a pixel-perfect round trip.

### Export formats
From an open document, use the format buttons to export `.docx`, `.pdf`, `.xlsx`, `.pptx` or `.txt`. These exports contain the document's readable text. They do not recreate the full original spreadsheet formulas, presentation layouts, embedded media or advanced formatting.

### Image OCR (optional)
The dashboard includes an image-to-text action for JPG, PNG and WebP. Install the Python packages:

```bash
pip install -r requirements-ocr.txt
```

Also install the Tesseract OCR system application and ensure its executable is on the server PATH. OCR is not enabled by Python packages alone. OCR results depend on image quality and installed language data. For Hausa or Arabic, install the matching Tesseract language packs and configure the OCR language in `main.py` before use; the default is Tesseract's default language.

### Stage 5 API endpoints
- `POST /api/import` — authenticated multipart upload; returns `{title, content, source_format, filename}`.
- `POST /api/export/{fmt}` — authenticated JSON `{title, content}`; returns a file download.
- `POST /api/ocr` — authenticated multipart image upload; returns extracted text. Requires optional OCR packages and system Tesseract.

The frontend provides Import and Scan Image actions on the dashboard and export buttons in the editor. Always inspect imported/OCR text before relying on it, especially for legal, financial or academic documents.
